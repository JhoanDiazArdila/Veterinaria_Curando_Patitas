



package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum ServiceType {
    VACCINATION,
    ADDITIONAL_SERVICE,
    MEDICAL_CONSULTATIONS,
    SURGICAL_PROCEDURES,
    ADOPTIONS;

    
  public static ServiceType chooseServiceType(int chooseType) {
        switch(chooseType) {
            case 1: return ServiceType.VACCINATION;
            case 2: return ServiceType.ADDITIONAL_SERVICE;
            case 3: return ServiceType.MEDICAL_CONSULTATIONS;
            case 4: return ServiceType.SURGICAL_PROCEDURES;
            case 5: return ServiceType.ADOPTIONS;
            default: throw new IllegalArgumentException("Tipo de Servicio no válido");
        }
    }
    
    
}
