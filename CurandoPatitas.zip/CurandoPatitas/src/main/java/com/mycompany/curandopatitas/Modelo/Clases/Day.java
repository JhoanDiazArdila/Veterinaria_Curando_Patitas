/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum Day {
    
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY;
    
    public static Day chooseDay(int chooseDay) {
        switch(chooseDay) {
            case 1: return Day.MONDAY;
            case 2: return Day.TUESDAY;
            case 3: return Day.WEDNESDAY;
            case 4: return Day.THURSDAY;
            case 5: return Day.FRIDAY;
            case 6: return Day.SATURDAY;
            case 7: return Day.SUNDAY;
            default: throw new IllegalArgumentException("Dia no válido");
        }
    }
    
}
