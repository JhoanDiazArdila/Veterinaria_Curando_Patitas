/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;


import com.mycompany.curandopatitas.Modelo.Clases.Inventory;
import com.mycompany.curandopatitas.Modelo.Clases.ItemType;
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Clases.ServiceType;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 *
 * @author jhoan
 */
public class ServiceController {
    
    
    public static boolean createService(ServiceType serviceType, String name, 
            String description, double standarPrice)throws SQLException{
        
        Service sv1 = new Service(serviceType, name, description, standarPrice);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Services (service_type, name, description, standar_price) VALUES (?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(sv1.getServiceType().name(), 
                sv1.getName(),sv1.getDescription(), sv1.getStandarPrice());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el Servicio");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    public static boolean updateService(String description, double standarPrice, int serviceId)throws SQLException {
        
        Service sv1 = new Service(serviceId, description, standarPrice);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Services SET description = ?, standar_price = ? WHERE service_id = ?";
        
        List<Object> parametros = Arrays.asList(sv1.getDescription(),
                sv1.getStandarPrice(), sv1.getServiceId());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar el Servicio");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    
    public static boolean deleteService(int serviceId) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Services WHERE service_id = ?";
        
        List<Object> parametros = Arrays.asList(serviceId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El Servicio fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el Servicio.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    
    public static Service getService(int serviceId) throws SQLException {
        
        Service sv1 = new Service(1, ServiceType.VACCINATION, "aja", "ojo", 20.0);
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Services WHERE service_id = ?";
        List<Object> parametros = Arrays.asList(serviceId);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                sv1.setServiceId(rs.getInt("service_id"));
                sv1.setServiceType(ServiceType.valueOf(rs.getString("service_type")));
                sv1.setName(rs.getString("name"));
                sv1.setDescription(rs.getString("description"));
                sv1.setStandarPrice(rs.getDouble("standar_price"));
            }
            rs.close();
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Dueño: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return sv1;
    }
    
    
    public static List<Service> getServiceList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<Service> serviceList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Services";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                Service sv1 = new Service(1, ServiceType.VACCINATION, "aja", "ojo", 20.0);
                sv1.setServiceId(rs.getInt("service_id"));
                sv1.setServiceType(ServiceType.valueOf(rs.getString("service_type")));
                sv1.setName(rs.getString("name"));
                sv1.setDescription(rs.getString("description"));
                sv1.setStandarPrice(rs.getDouble("standar_price"));
                
                serviceList.add(sv1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Servicio: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return serviceList;
    }
    
    
    public static void showServiceList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<Service> services = getServiceList();
            System.out.println("~~~~~~~ LISTA DE SERVICIOS ~~~~~~~");
            for(Service sv1 : services){
                System.out.println("Service ID: " + sv1.getServiceId());
                System.out.println("Service Type: " + sv1.getServiceType());
                System.out.println("Name: " + sv1.getName());
                System.out.println("Description: " + sv1.getDescription());
                System.out.println("Standar Price: " + sv1.getStandarPrice());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los Servicios: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
    
    
    
    // (Añadir, eliminar) item a servicio para tabla de muchos a muchos entre Inventory y Servicio
    
    
    public static boolean addItemToService(int itemId, int serviceId, int quantity)throws SQLException{
        
        Service service = getService(serviceId);
        Inventory item = InventoryController.getItem(itemId);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insertion = "INSERT INTO Items_used_services (item_id, service_id, quantity) VALUES(?,?,?)";
        List<Object> parameters = Arrays.asList( item.getItemId(),service.getServiceId(),quantity);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insertion, parameters)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar Articulos al Servicio");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    public static boolean deleteItemFromService(int itemId, int serviceId)throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        
        String delete = "DELETE FROM Items_used_services WHERE item_id = ? AND service_id = ?";
        List<Object> parameters = Arrays.asList(itemId,serviceId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(delete, parameters)){
                    System.out.println("El Articulo fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el Articulo.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
        
    }
    
    
    // METODO PARA MOSTRAR ITEMS DEL SERVICIO 
    
    public static void showItemsAddedToService(int serviceId) throws SQLException{
        
        Service service = getService(serviceId);
        List<Inventory> inventoryList = new ArrayList<>();
        try{
            CRUD.setConnection(Conexion.getConexion());
        
            String obtener = "SELECT * FROM Items_used_services AS ius JOIN Inventory AS i ON ius.item_id = i.item_id WHERE service_id = ?";
            List<Object> parametros = Arrays.asList(serviceId);
            ResultSet rs = CRUD.consultarBD1(obtener,parametros);
            while(rs.next()){
                Inventory in1 = new Inventory();
                in1.setItemId(rs.getInt("item_id"));
                in1.setName(rs.getString("name"));
                in1.setItemType(ItemType.valueOf(rs.getString("item_type")));
                in1.setSubType(rs.getString("sub_type"));
                in1.setManufacturer(rs.getString("manufacturer"));
                in1.setLotNumber(rs.getString("lot_number"));
                in1.setSellPrice(rs.getDouble("sell_price"));
                in1.setPurchasePrice(rs.getDouble("purchase_price"));
                in1.setExpirationDate(rs.getDate("expiration_date").toLocalDate());
                in1.setQuantity(rs.getInt("quantity"));
                
                inventoryList.add(in1);
            }
            System.out.println("~~~~~~~~~~~ LISTA DE ARTICULOS EN SERVICIO ~~~~~~~~~~~");
            for(Inventory in1 : inventoryList){
                System.out.println("Service ID: " + service.getServiceId());
                System.out.println("Service Name: " + service.getServiceName());
                System.out.println("Service Type: " + service.getServiceType());
                System.out.println("Item ID: " + in1.getItemId());
                System.out.println("Item Name: " + in1.getName());
                System.out.println("Item Type: " + in1.getItemType());
                System.out.println("Sub Type: " + in1.getSubType());
                System.out.println("Manufacturer: " + in1.getManufacturer());
                System.out.println("Lot Number: " + in1.getLotNumber());
                System.out.println("Sell Price: " + in1.getSellPrice());
                System.out.println("Purchase Price: " + in1.getPurchasePrice());
                System.out.println("Expiration Date: " + in1.getExpirationDate());
                System.out.println("Quantity: " + in1.getQuantity());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los items: " + e.getMessage());
            CRUD.cerrarConexion();
        }
    }
    
    
  
    
    
    
    
}
