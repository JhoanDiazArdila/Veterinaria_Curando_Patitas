/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

import com.mycompany.curandopatitas.Modelo.Clases.CompanyInformation;
import com.mycompany.curandopatitas.Modelo.Clases.CompanyNotification;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author jhoan
 */
public class CompanyNotificationController {
    
    
    public static boolean createCompanyNotification(
            CompanyInformation nit, String subject, String description){
        
        CompanyNotification n1 = new CompanyNotification(
                nit, subject, description);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = 
                "INSERT INTO Company_notification (NIT, subject, notification_date_time, descripction) VALUES (?, ?, ?, ?)";
        
        List<Object> parametros = Arrays.asList(
                n1.getNitString(), n1.getSubject(), n1.getNotificationDateTime(), n1.getDescription());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar la Notificacion");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    public static boolean updateCompanyNotification(String subject, 
            String description, int general_notification_id)throws SQLException{
        
        CompanyNotification n1 = new CompanyNotification(subject, description);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Company_notification SET subject = ?, descripction = ? WHERE general_notification_id = ?";
        
        List<Object> parametros = Arrays.asList(n1.getSubject(),
                n1.getDescription(), n1.getGeneral_notification_id());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar notificacion");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    
    public static boolean deleteCompanyNotification(String general_notification_id) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Company_notification WHERE general_notification_id = ?";
        
        List<Object> parametros = Arrays.asList(general_notification_id);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El Notificacion fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar Notificacion.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    
    public static CompanyNotification getCompanyNotification(String general_notification_id) throws SQLException {
        
        CompanyNotification cn1 = new CompanyNotification();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Company_notification WHERE general_notification_id = ?";
        List<Object> parametros = Arrays.asList(general_notification_id);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                cn1.setGeneral_notification_id(rs.getInt("general_notification_id"));
                cn1.setNit(new CompanyInformation(rs.getString("NIT")));
                cn1.setSubject(rs.getString("subject"));
                // Convertir Timestamp a LocalDateTime
                Timestamp timestamp = rs.getTimestamp("notification_date_time");
                if (timestamp != null) {
                    cn1.setNotificationDateTime(timestamp.toLocalDateTime());
                }
                cn1.setDescription(rs.getString("descripction"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener la Notificacion: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return cn1;
    }
    
    
    public static List<CompanyNotification> getNotifiacionList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<CompanyNotification> notificationList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Company_notification";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                CompanyNotification ow1 = new CompanyNotification();
                ow1.setGeneral_notification_id(rs.getInt("general_notification_id"));
                ow1.setNit(new CompanyInformation(rs.getString("NIT")));
                ow1.setSubject(rs.getString("subject"));
                Timestamp timestamp = rs.getTimestamp("notification_date_time");
                if (timestamp != null) {
                    ow1.setNotificationDateTime(timestamp.toLocalDateTime());
                }
                ow1.setDescription(rs.getString("descripction"));
                
                notificationList.add(ow1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener La compañia: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return notificationList;
    }
    
    
    public static void showNotificationList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<CompanyNotification> notifications = getNotifiacionList();
            
            System.out.println("~~~~~~~ LISTA DE NOTIFICACIONES ~~~~~~~");
            for(CompanyNotification ow1 : notifications){
                System.out.println("Notification ID: " + ow1.getGeneral_notification_id());
                System.out.println("NIT: " + ow1.getNitString());
                System.out.println("Subject: " + ow1.getSubject());
                System.out.println("Notification DateTime: " + ow1.getNotificationDateTime());
                System.out.println("Descripction: " + ow1.getDescription());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener las compañias: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
    
    
    
    
    
    
}
