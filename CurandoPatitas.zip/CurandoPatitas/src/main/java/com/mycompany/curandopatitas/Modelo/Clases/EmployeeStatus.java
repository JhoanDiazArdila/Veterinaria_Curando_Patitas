/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum EmployeeStatus {
    ACTIVE,
    INACTIVE,
    VACATIONS;

    public static EmployeeStatus chooseEmployeeStatus(int chooseEmployeeStatus) {
        switch(chooseEmployeeStatus) {
            case 1: return EmployeeStatus.ACTIVE;
            case 2: return EmployeeStatus.INACTIVE;
            case 3: return EmployeeStatus.VACATIONS;
            default: throw new IllegalArgumentException("Estado no válido");
        }
    }
    
}
