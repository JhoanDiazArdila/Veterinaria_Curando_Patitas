/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Vista;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author jhoan
 */
public class MenuVeterinarian {
    private static Scanner scanner = new Scanner(System.in);
    
    
    public static void mostrarMenu() { 
        System.out.println("~~~ Menu Administrador ~~~"); 
        int opcion = -1; 
        do {
            try {
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("1. Registrarse como Alumno");
                System.out.println("2. Verificar notas");
                System.out.println("3. Modificar Datos");
                System.out.println("4. Ver asignaturas");
                System.out.println("0. Salir");
                System.out.print("Seleccione una opción: ");

                opcion = scanner.nextInt();
                scanner.nextLine(); 

                switch (opcion) {
                    case 1 -> registrarAlumno();
                    case 2 -> verificarNotas();
                    case 3 -> modificarDatos();
                    case 4 -> verAsignaturas();
                    case 0 -> System.out.println("Saliendo del programa...");
                    default -> System.out.println("Opción no válida, intenta de nuevo.");
                }
            } catch (InputMismatchException e) {
                // Capturar errores por entrada de datos no numéricos
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) {
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            }
        } while (opcion != 0);
    
    
    }
}
