/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

import com.mycompany.curandopatitas.Modelo.Clases.CompanyInformation;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author jhoan
 */
public class CompanyInformationController {
    
    
    public static boolean createCompany(String identification, String name, 
            String phone, String email, String address)throws SQLException{
        
        CompanyInformation ow1 = new CompanyInformation(identification, name, phone, email, address);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Company_information (NIT, name, address, phone, email) VALUES (?, ?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(ow1.getIdentification(), 
                ow1.getName(),ow1.getAddress(),ow1.getPhone(),ow1.getEmail());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el Informacion de Compañia");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    
    public static boolean updateCompany(String identification, String phone, String email, String address)throws SQLException {
        
        CompanyInformation ow1 = new CompanyInformation(identification, phone, email, address);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Company_information SET phone = ?, email = ?, address = ? WHERE NIT = ?";
        
        List<Object> parametros = Arrays.asList(ow1.getPhone(),ow1.getEmail(),ow1.getAddress(),ow1.getIdentification());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar Compañia");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    
    
    public static boolean deleteCompany(String identification) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Company_information WHERE NIT = ?";
        
        List<Object> parametros = Arrays.asList(identification);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("La compañia fue eliminada exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar compañia.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    
    
    public static CompanyInformation getCompany(String identification) throws SQLException {
        
        CompanyInformation ow1 = new CompanyInformation();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Company_information WHERE NIT = ?";
        List<Object> parametros = Arrays.asList(identification);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                ow1.setIdentification(rs.getString("NIT"));
                ow1.setName(rs.getString("name"));
                ow1.setAddress(rs.getString("address"));
                ow1.setPhone(rs.getString("phone"));
                ow1.setEmail(rs.getString("email"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener la Compañia: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return ow1;
    }
    
    
    public static List<CompanyInformation> getCompanyList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<CompanyInformation> companyList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Company_information";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                CompanyInformation ow1 = new CompanyInformation();
                ow1.setIdentification(rs.getString("NIT"));
                ow1.setName(rs.getString("name"));
                ow1.setAddress(rs.getString("address"));
                ow1.setPhone(rs.getString("phone"));
                ow1.setEmail(rs.getString("email"));
                
                companyList.add(ow1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener La compañia: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return companyList;
    }
    
    
    public static void showCompanyList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<CompanyInformation> companies = getCompanyList();
            System.out.println("~~~~~~~ LISTA DE COMPAÑIAS ~~~~~~~");
            for(CompanyInformation ow1 : companies){
                System.out.println("Owner ID: " + ow1.getIdentification());
                System.out.println("Full Name: " + ow1.getName());
                System.out.println("Address: " + ow1.getAddress());
                System.out.println("Phone: " + ow1.getPhone());
                System.out.println("Email: " + ow1.getEmail());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener las compañias: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
    
    
    
    
    
    
}
