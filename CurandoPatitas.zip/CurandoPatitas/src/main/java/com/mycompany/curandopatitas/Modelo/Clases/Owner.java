


package com.mycompany.curandopatitas.Modelo.Clases;

import java.util.*;

/**
 *
 * @author jhoan
 */
public class Owner extends User {
    private String emergencyName;
    private String emergencyContact;
    
    
    
    //CONSTRUCTOR
    public Owner(){}
    
    public Owner(String identification){
        this.identification = identification;
    }
    
    public Owner(String identification, String address, String phone, String email){
        this.identification = identification;
        this.address = address;
        this.phone = phone;
        this.email = email;
    }
    
    public Owner(String emergencyName, String emergencyContact, String identification, 
            String name, String phone, String email, String address) {
        
        super(identification, name, phone, email, address);
        this.emergencyName = emergencyName;
        this.emergencyContact = emergencyContact;
    }
    
    
    // GETTERS && SETTERS

    public String getEmergencyName() {
        return emergencyName;
    }

    public void setEmergencyName(String emergencyName) {
        this.emergencyName = emergencyName;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public void setEmergencyContact(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }


    // LIST
//    
//    public List<Animal> getPetsList() {
//        return petsList;
//    }
//    
//    public void addPet(Animal pet) {
//        this.petsList.add(pet);
//    }
//    
//    public void removePet(Animal pet) {
//        this.petsList.remove(pet);
//    }
//    
//    public Animal getPet(int index) {
//        return this.petsList.get(index);
//    }
    
    
    @Override
    public String toString() {
        return "~~~~~~~~~ OWNER ~~~~~~~~~" + 
                "\nIdentification: " + identification + 
                "\nName: " + name + 
                "\nPhone: " + phone + 
                "\nEmail: " + email + 
                "\nAddress: " + address +
                "\nEmergency Name:" + emergencyName + 
                "\nEmergency Contact: " + emergencyContact + 
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }
    
    
    
    
    
}
