/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

import com.mycompany.curandopatitas.Modelo.Clases.Animal;
import com.mycompany.curandopatitas.Modelo.Clases.Appoiment;
import com.mycompany.curandopatitas.Modelo.Clases.AppointmentStatus;
import com.mycompany.curandopatitas.Modelo.Clases.Dog;
import com.mycompany.curandopatitas.Modelo.Clases.Employee;
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author jhoan
 */
public class AppoimentController {
    
    
    public static boolean createAppoiment(Service serviceId, Employee employId, Animal petId, 
            LocalDateTime entryDateTime, LocalDateTime exitDateTime, String visitReason, 
            String diagnosis, String recomendations, String prescriptionMedicines, 
            AppointmentStatus status){
    
        
        Appoiment ap1 = new Appoiment(serviceId, employId, petId, 
                entryDateTime, exitDateTime, visitReason, diagnosis, 
                recomendations, prescriptionMedicines, status);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = 
                "INSERT INTO pet_services_appoinment "
                + "(service_id, employ_id, pet_id, entry_date_time, exit_date_time, "
                + "visit_reason, diagnosis, recomendations, prescription_medicines, apoimet_status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
        List<Object> parametros = Arrays.asList(
                ap1.getServiceIdString(),
                ap1.getEmployIdString(),
                ap1.getPetIdString(),
                ap1.getEntryDateTimeAsTimestamp(),
                ap1.getExitDateTimeAsTimestamp(),
                ap1.getVisitReason(),
                ap1.getDiagnosis(),
                ap1.getRecomendations(),
                ap1.getPrescriptionMedicines(),
                ap1.getStatus().name());
        
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar la Cita");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    public static boolean updateAppoiment(int appoimentId, Employee employId, 
            LocalDateTime entryDateTime, LocalDateTime exitDateTime,
            AppointmentStatus status)throws SQLException{
        
        Appoiment ap1 = new Appoiment(appoimentId, employId, entryDateTime, exitDateTime, status);
        
        CRUD.setConnection(Conexion.getConexion());
        String actualizacion = 
                "UPDATE pet_services_appoinment SET employ_id = ?, entry_date_time = ?, "
                + "exit_date_time = ?, apoimet_status = ? WHERE appointment_pet_service_id = ?";
        
        List<Object> parametros = Arrays.asList(
                ap1.getEmployIdString(),
                ap1.getEntryDateTimeAsTimestamp(),
                ap1.getExitDateTimeAsTimestamp(),
                ap1.getStatus().name(),
                ap1.getAppoimentId());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar la Cita");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    
    
    public static boolean deleteAppoiment(int appoimentId) throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        String delete = "DELETE FROM pet_services_appoinment WHERE appointment_pet_service_id = ?";
        
        List<Object> parameters = Arrays.asList(appoimentId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(delete, parameters)){
                    System.out.println("La cita fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar La cita.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    
    }
    
    
    public static Appoiment getAppoiment(int appoimentId) throws SQLException {
        
        Appoiment ap1 = new Appoiment();
        CRUD.setConnection(Conexion.getConexion());
        
        String obtener = "SELECT * FROM pet_services_appoinment WHERE appointment_pet_service_id = ?";
        List<Object> parametros = Arrays.asList(appoimentId);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                ap1.setAppoimentId(rs.getInt("appointment_pet_service_id"));
                ap1.setServiceId(new Service(rs.getInt("service_id")));
                ap1.setEmployId(new Employee(rs.getString("employ_id")));
                ap1.setPetId(new Dog(rs.getInt("pet_id")));
                ap1.setEntryDateTime(rs.getTimestamp("entry_date_time").toLocalDateTime());
                ap1.setExitDateTime(rs.getTimestamp("exit_date_time").toLocalDateTime());
                ap1.setVisitReason(rs.getString("visit_reason"));
                ap1.setDiagnosis(rs.getString("diagnosis"));
                ap1.setRecomendations(rs.getString("recomendations"));
                ap1.setPrescriptionMedicines(rs.getString("prescription_medicines"));
                ap1.setStatus(AppointmentStatus.valueOf(rs.getString("apoimet_status")));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener La Cita " + ex.getMessage());
            throw ex; 
        } finally {
            CRUD.cerrarConexion();
        }
        return ap1;
    }
    
    public static List<Appoiment> getInventoryList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<Appoiment> apoimentList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM pet_services_appoinment";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                Appoiment ap1 = new Appoiment();
                ap1.setAppoimentId(rs.getInt("appointment_pet_service_id"));
                ap1.setServiceId(new Service(rs.getInt("service_id")));
                ap1.setEmployId(new Employee(rs.getString("employ_id")));
                ap1.setPetId(new Dog(rs.getInt("pet_id")));
                ap1.setEntryDateTime(rs.getTimestamp("entry_date_time").toLocalDateTime());
                ap1.setExitDateTime(rs.getTimestamp("exit_date_time").toLocalDateTime());
                ap1.setVisitReason(rs.getString("visit_reason"));
                ap1.setDiagnosis(rs.getString("diagnosis"));
                ap1.setRecomendations(rs.getString("recomendations"));
                ap1.setPrescriptionMedicines(rs.getString("prescription_medicines"));
                ap1.setStatus(AppointmentStatus.valueOf(rs.getString("apoimet_status")));
                
                apoimentList.add(ap1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener la lista de Citas: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return apoimentList;
    }
    
    
    public static void showInventoryList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<Appoiment> appoiments = getInventoryList();
            System.out.println("~~~~~~~~~~~~~ LISTA DE CITAS ~~~~~~~~~~~~~");
            for(Appoiment in1 : appoiments){
                System.out.println("Appoiment ID: " + in1.getAppoimentId());
                System.out.println("Service ID: " + in1.getServiceId());
                System.out.println("Emplo ID: " + in1.getEmployId());
                System.out.println("Pet ID: " + in1.getPetId());
                System.out.println("Entry Date Time: " + in1.getEntryDateTime());
                System.out.println("Exit Date Time: " + in1.getExitDateTime());
                System.out.println("Visit Reason: " + in1.getVisitReason());
                System.out.println("Diagnosis: " + in1.getDiagnosis());
                System.out.println("Recomendations: " + in1.getRecomendations());
                System.out.println("Prescription Medicines: " + in1.getPrescriptionMedicines());
                System.out.println("Appoiment Status: " + in1.getStatus());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener las Citas: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
    
    // MOSTRAR Todas Las citas de una Mascota  Recibir parametro Appoimente Status en INT.
    
    
    
}
