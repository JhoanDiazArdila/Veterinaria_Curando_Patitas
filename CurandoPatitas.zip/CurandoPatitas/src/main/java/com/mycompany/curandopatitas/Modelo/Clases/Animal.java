

package com.mycompany.curandopatitas.Modelo.Clases;


import java.time.LocalDate;

/**
 *
 * @author jhoan
 */
public abstract class Animal {
    
    protected int petId;
    protected Owner owner;
    protected String name;
    protected Behavior behavior;
    protected int age;
    protected LocalDate birthdate;
    protected Sex sex;
    protected String microchipNumber;
    protected String photoPath;
    protected Double weight;
    protected Size size;
    protected String allergies;
    protected String medicalConditions;
    
    
 //    protected size ENUM("BIG", "MEDIUM", "SMALL");   
//    protected sex ENUM("MALE", "FEMALE");    
    //    protected species ENUM("MAMMAL", "BIRD", "REPTILE");
//    protected type ENUM("CAT", "DOG", "BLACK MAMBA", "TURTLE", "PINK FLAMINGO", "OWL");
//    protected behavior ENUM("AGGRESSIVE", "PASSIVE");
    
    
    
  // Constructor
    public Animal(){}

    public Animal(Owner owner, String name, Behavior behavior, 
            int age, LocalDate birthdate, Sex sex, String microchipNumber, 
            String photoPath, Double weight, Size size, String allergies, String medicalConditions) {
        
        this.owner = owner;
        this.name = name;
        this.behavior = behavior;
        this.age = age;
        this.birthdate = birthdate;
        this.sex = sex;
        this.microchipNumber = microchipNumber;
        this.photoPath = photoPath;
        this.weight = weight;
        this.size = size;
        this.allergies = allergies;
        this.medicalConditions = medicalConditions;
    }
        
    
    // GETTERS AND SETTERS
    
    
    public abstract String getSpicie();
//    public abstract void setSpicie(String spicie);
    
    public abstract String getType();
//    public abstract void setType(String type);
    
    public abstract String getBreed();
    public abstract void setBreed(String breed);

    
    
    public int getPetId() {
        return petId;
    }

    public void setPetId(int petId) {
        this.petId = petId;
    }

    public Owner getOwner() {
        return owner;
    }
    
    public String getOwnerId(){
        return (owner != null) ? owner.getIdentification() : "Sin dueño";
    }
    
    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Behavior getBehavior() {
        return behavior;
    }

    public void setBehavior(Behavior behavior) {
        this.behavior = behavior;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
    }

    public Sex getSex() {
        return sex;
    }

    public void setSex(Sex sex) {
        this.sex = sex;
    }

    public String getMicrochipNumber() {
        return microchipNumber;
    }

    public void setMicrochipNumber(String microchipNumber) {
        this.microchipNumber = microchipNumber;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }

    public String getAllergies() {
        return allergies;
    }

    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }

    public String getMedicalConditions() {
        return medicalConditions;
    }

    public void setMedicalConditions(String medicalConditions) {
        this.medicalConditions = medicalConditions;
    }
    
    
    
    @Override
    public String toString() {
        return "Animal" + 
                "\nPet Id:" + petId + 
                "\nOwner:" + owner + 
                "\nName: " + name + 
                "\nBehavior: " + behavior + 
                "\nAge: " + age + 
                "\nBirthdate: " + birthdate + 
                "\nSex: " + sex + 
                "\nMicrochip Number: " + microchipNumber + 
                "\nPhoto Path: " + photoPath + 
                "\nWeight: " + weight + 
                "\nSize:" + size + 
                "\nAllergies: " + allergies + 
                "\nMedical Conditions: " + medicalConditions;
    }
    
    
    
    
    
    
    
}
