/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

import java.time.LocalDateTime;

/**
 *
 * @author jhoan
 */
public class CompanyNotification {
    
    private int general_notification_id;
    private CompanyInformation nit;
    private String subject;
    private LocalDateTime notificationDateTime;
    private String description;
    
    //CONSTRUCTOR
    public CompanyNotification(){}
    
    public CompanyNotification(int general_notification_id){
        this.general_notification_id = general_notification_id;
        this.notificationDateTime = LocalDateTime.now();
    }
    
    public CompanyNotification(String subject, String description){
        this.subject = subject;
        this.description = description;
        this.notificationDateTime = LocalDateTime.now();
    }
    
    public CompanyNotification(CompanyInformation nit,
            String subject, String description){
        
        this.nit = nit;
        this.subject = subject;
        this.notificationDateTime = LocalDateTime.now();
        this.description = description;
    }

    
    
    
    
    public int getGeneral_notification_id() {
        return general_notification_id;
    }

    public void setGeneral_notification_id(int general_notification_id) {
        this.general_notification_id = general_notification_id;
    }

    public CompanyInformation getNit() {
        return nit;
    }
 //-------------------------------------------------
    public String getNitString() {
        return nit.getIdentification();
    }
 //------------------------------------------------- 
    public void setNit(CompanyInformation nit) {
        this.nit = nit;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public LocalDateTime getNotificationDateTime() {
        return notificationDateTime;
    }

    public void setNotificationDateTime(LocalDateTime notificationDateTime) {
        this.notificationDateTime = notificationDateTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "~~~~~ Company Notification ~~~~~" + 
                "\nGeneral notification id:" + general_notification_id + 
                "\nNit: " + nit + 
                "\nSubject: " + subject + 
                "\nNotification Date Time: " + notificationDateTime + 
                "\nDescription: " + description + 
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }
    
    
    
    
    
    
    
    
    
}











//
//public class Owner extends User{
//    private String address;
//    private String emergencyContact;
//    private LocalDateTime registerDate;
//    ArrayList<Animal> pets = new ArrayList();
//    private ClubMember clubMembership;
//
//    public Owner(int id, String name, String cedula, String phone, String email, String adress, String emergencyContact, LocalDateTime registerDate) {
//        super(id, name, cedula, phone, email);
//        this.address = adress;
//        this.emergencyContact = emergencyContact;
//        this.registerDate = registerDate;
//    }
//
//    public Owner(int id, String name, String cedula, String phone, String email, String address, String emergencyContact, LocalDateTime registerDate, ClubMember clubMembership) {
//        super(id, name, cedula, phone, email);
//        this.address = address;
//        this.emergencyContact = emergencyContact;
//        this.registerDate = registerDate;
//        this.clubMembership = clubMembership;
//    }
//
//    public ArrayList<Animal> getPets() {
//        return pets;
//    }
//
//    public void setPets(ArrayList<Animal> pets) {
//        this.pets = pets;
//    }


//-*--------------------------------------------------------------------



//public static ArrayList<Animal> verMascotas(Owner owner) {
//    CRUD.setConexion(ConnectionDB.getConnection());
//    String sql = "SELECT m.ID, m.Nombre, m.Especie, m.Raza, m.FechaNacimiento, " +
//                 "m.Sexo, m.Microchip, m.Foto, m.Estatus, m.FechaRegistro " +
//                 "FROM Propietarios p " +
//                 "JOIN Mascotas m ON p.ID = m.ID_Propietario " +
//                 "WHERE p.ID = ?";
//    Object[] params = {owner.getId()};
//    ArrayList<Animal> mascotas = new ArrayList<>();
//    
//    try {
//        ResultSet rs = CRUD.consultarDB(sql, params);
//        while (rs != null && rs.next()) {
//            Animal animal = new Animal();
//            animal.setId(rs.getInt("ID"));
//            animal.setName(rs.getString("Nombre"));
//            animal.setSpecie(rs.getString("Especie"));
//            animal.setBreed(rs.getString("Raza"));
//            animal.setBirthDate(rs.getDate("FechaNacimiento").toLocalDate());
//            animal.setSex(Sex.valueOf(rs.getString("Sexo")));
//            animal.setMicroChip(rs.getString("Microchip"));
//            animal.setPhoto(rs.getString("Foto"));
//            animal.setPetStatus(PetStatus.valueOf(rs.getString("Estatus")));
//            animal.setRegisterDate(rs.getTimestamp("FechaRegistro").toLocalDateTime());
//            animal.setOwner(owner);
//            
//            mascotas.add(animal);
//        }
//    } catch (SQLException ex) {
//        Logger.getLogger(OwnerController.class.getName()).log(Level.SEVERE, null, ex);
//    }
//    
//    return mascotas;
//}




