/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */

import com.mycompany.curandopatitas.Modelo.Clases.AditionalCharges;
import com.mycompany.curandopatitas.Modelo.Clases.Size;
import com.mycompany.curandopatitas.Modelo.Clases.Type;
import com.mycompany.curandopatitas.Modelo.Clases.Vaccination;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class AditionalChargesController {
    
    //Create Aditional Charges 
    public static boolean createAditionalCharges( Type type, Size size, double multiplierValue)throws SQLException{
        
        AditionalCharges ac1 = new AditionalCharges(type, size, multiplierValue);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Additional_charges (type, size, multiplier_value) VALUES (?, ?, ?)";

        List<Object> parametros = Arrays.asList(ac1.getType().name(),ac1.getSize().name(),ac1.getMultiplierValue());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el cargo adicional");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    //Update Aditional Charges 
    public static boolean updateAditionalCharges(int chargeId, double multiplierValue)throws SQLException {
        
        AditionalCharges ac1 = new AditionalCharges(chargeId, multiplierValue);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Additional_charges SET multiplier_value = ? WHERE charge_id = ?";
        
        
        List<Object> parametros = Arrays.asList(ac1.getMultiplierValue(),ac1.getChargeId());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error el cargo adicional");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    //Delete Aditional Charges 
    public static boolean deleteAditionalCharge (int chargeId) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Additional_charges WHERE charge_id = ?";
        
        List<Object> parametros = Arrays.asList(chargeId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El el cargo adicional fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el el cargo adicional.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    //Get Aditional Charges
    
    public static AditionalCharges getAditionalCharge(int chargeId) throws SQLException {
        
        AditionalCharges ac1 = new AditionalCharges();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Additional_charges WHERE charge_id = ?";
        List<Object> parametros = Arrays.asList(chargeId);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                ac1.setChargeId(rs.getInt("charge_id"));
                ac1.setType(Type.valueOf(rs.getString("type")));
                ac1.setSize(Size.valueOf(rs.getString("size")));
                ac1.setMultiplierValue(rs.getDouble("multiplier_value"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el cargo adicional: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return ac1;
    }
    
    //Show Aditional Charges List
    
    public static List<AditionalCharges> getAditionalChargesList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<AditionalCharges> AditionalChargesList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Additional_charges";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                AditionalCharges ac1 = new AditionalCharges();
                ac1.setChargeId(rs.getInt("charge_id"));
                ac1.setType(Type.valueOf(rs.getString("type")));
                ac1.setSize(Size.valueOf(rs.getString("size")));
                ac1.setMultiplierValue(rs.getDouble("multiplier_value"));
                
                AditionalChargesList.add(ac1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener el cargo adicional: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return AditionalChargesList;
    }
    
    public static void showAditionalChargesList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<AditionalCharges> aditionalCharges = getAditionalChargesList();
            System.out.println("~~~~~~~ LISTA DE CARGOS ADICIONALES ~~~~~~~");
            for(AditionalCharges ac1 : aditionalCharges){
                System.out.println("Cargo adicional ID: " + ac1.getChargeId());
                System.out.println("Tipo : " + ac1.getType()) ;
                System.out.println("Tamaño: " + ac1.getSize());
                System.out.println("Valor Multiplicador: " + ac1.getMultiplierValue());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los cargos adicionales: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
    
}

