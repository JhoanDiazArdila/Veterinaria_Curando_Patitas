


package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum Behavior {
    
    AGGRESSIVE, 
    PASSIVE;
    

    
    public static Behavior chooseBehavior(int chooseBehavior) {
        switch(chooseBehavior) {
            case 1: return Behavior.AGGRESSIVE;
            case 2: return Behavior.PASSIVE;
            default: throw new IllegalArgumentException("Comportamiento no válido");
        }
    }
    
    
    
}
