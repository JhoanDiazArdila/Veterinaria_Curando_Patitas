/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

import java.time.LocalDate;

/**
 *
 * @author jhoan
 */
public abstract class Bird extends Animal{
    
    protected String variety;
    

    // CONSTRUCTOR

    public Bird(){}
    
    public Bird(String variety, Owner owner, String name, Behavior behavior, int age, 
            LocalDate birthdate, Sex sex, String microchipNumber, String photoPath, 
            Double weight, Size size, String allergies, String medicalConditions) {
        
        
        super(owner, name, behavior, age, birthdate, sex, microchipNumber, 
                photoPath, weight, size, allergies, medicalConditions);
        
        this.variety = variety;
    }
    
    @Override
    public String getBreed() {
        return variety;
    }
    @Override
    public void setBreed(String breed){
        this.variety = breed;
    }
    
    @Override
    public String getSpicie(){
        return "BIRD";
    }
    
    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    
    
}
