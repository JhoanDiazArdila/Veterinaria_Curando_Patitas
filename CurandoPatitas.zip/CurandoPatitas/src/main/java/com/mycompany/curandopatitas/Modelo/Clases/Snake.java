/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

import java.time.LocalDate;

/**
 *
 * @author jhoan
 */
public class Snake extends Reptile{
    
    
    public Snake() {}

    public Snake(String subType, Owner owner, String name, Behavior behavior, 
            int age, LocalDate birthdate, Sex sex, String microchipNumber, 
            String photoPath, Double weight, Size size, String allergies, 
            String medicalConditions) {
        
        super(subType, owner, name, behavior, age, birthdate, sex, 
                microchipNumber, photoPath, weight, size, allergies, 
                medicalConditions);
        
    }

    
    @Override
    public String getType() {
        return "SNAKE";
    }
    
   
    
    @Override
    public String toString() {
        return "~~~~~~~~~~ SNAKE ~~~~~~~~~~" + 
                "\nPet Id:" + petId +
                "\nName: " + name + 
                "\nSex: " + sex + 
                "\nBehavior: " + behavior +
                "\nWeight: " + weight + 
                "\nSize:" + size + 
                "\nAge: " + age + 
                "\nBirthdate: " + birthdate + 
                "\nSpecie" + getSpicie()+
                "\nSub Specie" + getSubType()+
                "\nMicrochip Number: " + microchipNumber + 
                "\nPhoto Path: " + photoPath +
                "\nAllergies: " + allergies + 
                "\nMedical Conditions: " + medicalConditions +
                "\n" + owner ;
    }

    
    
}
