


package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum ItemType {
    MEDICATION, 
    VACCINE, 
    MEDICAL_SUPPLY;
    
   
    public static ItemType chooseItemType(int chooseItemType) {
        switch(chooseItemType) {
            case 1: return ItemType.MEDICATION;
            case 2: return ItemType.VACCINE;
            case 3: return ItemType.MEDICAL_SUPPLY;
            default: throw new IllegalArgumentException("Comportamiento no válido");
        }
    }
    
}
