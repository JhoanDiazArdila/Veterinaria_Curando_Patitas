/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Vista;

import com.mycompany.curandopatitas.Controlador.OwnerController;
import com.mycompany.curandopatitas.Modelo.Clases.Owner;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author jhoan
 */
public class MenuAdmin {
    private static Scanner scanner = new Scanner(System.in);
    
    
    public static void mostrarMenu() { 
        System.out.println("~~~ Menu Administrador ~~~"); 
        int opcion = -1; 
        do {
            try {
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("1. Manejar Dueños");
                System.out.println("2. Manejar Mascotas");
                System.out.println("3. Manejar Empleados");
                System.out.println("4. Manejar Servicios");
                System.out.println("5. Manejar Citas");
                System.out.println("6. Manejar Eventos");
                System.out.println("7. Manejar Inventario");
                System.out.println("8. Manejar Proveedores");
                System.out.println("9. Manejar Facturas");
                System.out.println("0. Salir");
                System.out.print("Seleccione una opción: ");

                opcion = scanner.nextInt();
                scanner.nextLine(); 

                switch (opcion) {
                    case 1 -> tableOwners();
                    case 2 -> tablePets();
                    case 3 -> tableEmployee();
                    case 4 -> tableServices();
                    case 5 -> tableAppoiments();
                    case 6 -> tableEvents();
                    case 7 -> tableInventory();
                    case 8 -> tableSuppliers();
                    case 9 -> tableInvoices();
                    case 0 -> System.out.println("Saliendo del programa...");
                    default -> System.out.println("Opción no válida, intenta de nuevo.");
                }
            } catch (InputMismatchException e) {
                // Capturar errores por entrada de datos no numéricos
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) {
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            }
        } while (opcion != 0);
    }
    
    
    public static void tableOwners() throws SQLException {
        
        System.out.println("~~~ Manejo de Datos Dueños ~~~"); 
        int opcion = -1; 
        do {
            System.out.println("1. Crear Dueño"); 
            System.out.println("2. Actualizar Dueño"); 
            System.out.println("3. Eliminar Dueño"); 
            System.out.println("4. Obtener Dueño");
            System.out.println("5. Mostrar Lista de Dueños");
            System.out.println("0. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            try {
                opcion = scanner.nextInt(); 
                scanner.nextLine(); 
                switch (opcion) {
                    case 1 -> { 
                        System.out.print("Nombre Completo: "); 
                        String name = scanner.nextLine();
                        System.out.print("Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Email: "); 
                        String email = scanner.nextLine(); 
                        System.out.print("Dirección: "); 
                        String address = scanner.nextLine(); 
                        System.out.print("Nombre de Contacto de Emergencia: "); 
                        String emergencyName = scanner.nextLine(); 
                        System.out.print("Teléfono de Contacto de Emergencia: ");
                        String emergencyContact = scanner.nextLine(); 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine(); 
                        OwnerController.createOwner(emergencyName, emergencyContact, identification, name, phone, email, address); 
                    } 
                    case 2 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        System.out.print("Nueva Dirección: "); 
                        String address = scanner.nextLine(); 
                        System.out.print("Nuevo Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Nuevo Email: "); 
                        String email = scanner.nextLine(); 
                        OwnerController.updateOwner(identification, address, phone, email); 
                    } 
                    case 3 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        OwnerController.deleteOwner(identification); 
                    } 
                    case 4 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        Owner owner = OwnerController.getOwner(identification); 
                        System.out.println(owner); 
                    } 
                    case 5 -> OwnerController.showOwnerList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida.");
                }
            } catch (InputMismatchException e) {
                // Capturar errores por entrada de datos no numéricos
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) {
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            }
        } while (opcion != 0);
    }
    
    
}
