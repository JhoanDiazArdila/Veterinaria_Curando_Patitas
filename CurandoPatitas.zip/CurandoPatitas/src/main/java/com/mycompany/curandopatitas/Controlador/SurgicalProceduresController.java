/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;



import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Clases.SurgicalProcedures;
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 *
 * @author jhoan
 */
public class SurgicalProceduresController {
    
    //Create SurgicalProcedures 
    public static boolean createSurgicalProcedures( Service serviceId, String preoperativeDetails, String procedureDetails, String postoperativeFollowUp, String recoveryEstimatedTime)throws SQLException{
        
        SurgicalProcedures sp1 = new SurgicalProcedures(serviceId, preoperativeDetails, procedureDetails, postoperativeFollowUp, recoveryEstimatedTime);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Surgical_Procedures (service_id,preoperative_details, procedure_details, postoperative_follow_up,recovery_estimated_time) VALUES (?, ?, ?, ?,?)";

        List<Object> parametros = Arrays.asList(serviceId.getServiceId(),sp1.getPreoperativeDetails(),sp1.getProcedureDetails(),sp1.getPostoperativeFollowUp(),sp1.getRecoveryEstimatedTime());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el procedimiento quirurgico");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    //Update SurgicalProcedures
    public static boolean upSurgicalProcedures(int surgicalProceduresId, String preoperativeDetails, String postoperativeFollowUp)throws SQLException {
        
        SurgicalProcedures sp1 = new SurgicalProcedures(surgicalProceduresId, preoperativeDetails, postoperativeFollowUp);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Surgical_Procedures SET preoperative_details = ?, postoperative_follow_up = ? WHERE service_id = ?";
        
        
        List<Object> parametros = Arrays.asList(sp1.getPreoperativeDetails(),sp1.getPostoperativeFollowUp(),sp1.getSurgicalProceduresId());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar el procedimiento quirurgico");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    //Delete SurgicalProcedures
    public static boolean deleteSurgicalProcedures(int surgicalProceduresId) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Surgical_Procedures WHERE service_id = ?";
        
        List<Object> parametros = Arrays.asList(surgicalProceduresId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El procedimiento quirurgico fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el procedimiento quirurgico.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    
    //Get SurgicalProcedures
    public static SurgicalProcedures getSurgicalProcedures(int surgicalProceduresId) throws SQLException {
        
        SurgicalProcedures sp1 = new SurgicalProcedures();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Surgical_Procedures WHERE service_id = ?";
        List<Object> parametros = Arrays.asList(surgicalProceduresId);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                sp1.setSurgicalProceduresId(rs.getInt("service_id"));
                sp1.setPreoperativeDetails(rs.getString("preoperative_details"));
                sp1.setProcedureDetails(rs.getString("procedure_details"));
                sp1.setPostoperativeFollowUp(rs.getString("postoperative_follow_up"));
                sp1.setRecoveryEstimatedTime(rs.getString("recovery_estimated_time"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el procedimiento quirurgico.: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return sp1;
    }
    
    //Show SurgicalProcedures List
    public static List<SurgicalProcedures> getSurgicalProceduresList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<SurgicalProcedures> surgicalProceduresList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Surgical_Procedures";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                SurgicalProcedures sp1 = new SurgicalProcedures();
                sp1.setSurgicalProceduresId(rs.getInt("service_id"));
                sp1.setPreoperativeDetails(rs.getString("preoperative_details"));
                sp1.setProcedureDetails(rs.getString("procedure_details"));
                sp1.setPostoperativeFollowUp(rs.getString("postoperative_follow_up"));
                sp1.setRecoveryEstimatedTime(rs.getString("recovery_estimated_time"));
                
                surgicalProceduresList.add(sp1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener el procedimiento quirurgico.: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return surgicalProceduresList;
    }
    
    public static void showSurgicalProceduresList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<SurgicalProcedures> surgicalProcedures = getSurgicalProceduresList();
            System.out.println("~~~~~~~ LISTA DE PROCEDIMIENTOS QUIRURGICOS ~~~~~~~");
            for(SurgicalProcedures sp1 : surgicalProcedures){
                System.out.println("Preocedimiento quirurgico ID: " + sp1.getSurgicalProceduresId());
                System.out.println("Detalle preoperativo: " + sp1.getPreoperativeDetails());
                System.out.println("Detalle procedimiento: " + sp1.getProcedureDetails());
                System.out.println("Seguimiento Post Operativo: " + sp1.getPostoperativeFollowUp());
                System.out.println("Tiempo de recuperacion estimada: " + sp1.getRecoveryEstimatedTime());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los  procedimientos quirurgicos.: " + e.getMessage());
            CRUD.cerrarConexion();
        }
    }
}

