/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

import java.time.LocalDate;

/**
 *
 * @author jhoan
 */
public abstract class Reptile extends Animal {
    
    protected String subType;
//    
    
    
    public Reptile(){}
    
    public Reptile(String subType, Owner owner, String name, Behavior behavior, int age, 
            LocalDate birthdate, Sex sex, String microchipNumber, String photoPath, 
            Double weight, Size size, String allergies, String medicalConditions) {
        
        
        super(owner, name, behavior, age, birthdate, sex, microchipNumber, 
                photoPath, weight, size, allergies, medicalConditions);
        
        this.subType = subType;
    }

    
    @Override
    public String getBreed() {
        return subType;
    }
    
    @Override
    public void setBreed(String breed){
        this.subType = breed;
    }
    
    @Override
    public String getSpicie(){
        return "REPTILE";
    }
    
    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }
    
}
