/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum AppointmentStatus {
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED;
    
    public static AppointmentStatus chooseAppoimentStatus(int chooseAppoimentStatus) {
        switch(chooseAppoimentStatus) {
            case 1: return AppointmentStatus.SCHEDULED;
            case 2: return AppointmentStatus.IN_PROGRESS;
            case 3: return AppointmentStatus.COMPLETED;
            case 4: return AppointmentStatus.CANCELLED;
            default: throw new IllegalArgumentException("Comportamiento no válido");
        }
    }
    
    
}
