/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

import java.time.LocalDate;

/**
 *
 * @author jhoan
 */
public class Cat extends Mammal{
    
    public Cat(){}

    public Cat(String breed, Owner owner, String name, Behavior behavior, 
            int age, LocalDate birthdate, Sex sex, String microchipNumber, 
            String photoPath, Double weight, Size size, String allergies, 
            String medicalConditions) {
        
        super(breed, owner, name, behavior, age, birthdate, sex, 
                microchipNumber, photoPath, weight, size, allergies, 
                medicalConditions);
        
    }
    
    
    @Override
    public String getType(){
        return "CAT";
    }
    
    
    @Override
    public String toString() {
        return "~~~~~~~~~~ CAT ~~~~~~~~~~" + 
                "\nPet Id:" + petId +
                "\nName: " + name + 
                "\nSex: " + sex + 
                "\nBehavior: " + behavior +
                "\nWeight: " + weight + 
                "\nSize:" + size + 
                "\nAge: " + age + 
                "\nBirthdate: " + birthdate + 
                "\nSpecie: " + getSpicie()+
                "\nSub Specie: " + getType()+
                "\nBreed: " + breed +
                "\nMicrochip Number: " + microchipNumber + 
                "\nPhoto Path: " + photoPath +
                "\nAllergies: " + allergies + 
                "\nMedical Conditions: " + medicalConditions +
                "\n" + owner ;
    }
    
    
    
    
}
