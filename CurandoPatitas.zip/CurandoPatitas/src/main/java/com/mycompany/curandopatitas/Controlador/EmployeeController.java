/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */


import com.mycompany.curandopatitas.Modelo.Clases.Day;
import com.mycompany.curandopatitas.Modelo.Clases.Employee;
import com.mycompany.curandopatitas.Modelo.Clases.EmployeeStatus;
import com.mycompany.curandopatitas.Modelo.Clases.JobPosition;
import com.mycompany.curandopatitas.Modelo.Clases.Schedule;
import com.mycompany.curandopatitas.Modelo.Clases.Size;
import com.mycompany.curandopatitas.Modelo.Clases.Type;
import com.mycompany.curandopatitas.Modelo.Clases.Vaccination;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;




public class EmployeeController {
    
    public static boolean createEmployee(JobPosition jobPosition, String digitalFingerPrintUrl, EmployeeStatus employeeStatus, String identification, String name, String phone, String email, String address)throws SQLException{
        
        Employee em1 = new Employee(jobPosition, digitalFingerPrintUrl, employeeStatus, identification, name, phone, email, address);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Employees (employ_id, full_name,  phone, address, email, digital_finger_print_url, job_position,employee_status,salary) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(em1.getIdentification(), em1.getName(),
                em1.getPhone(), em1.getAddress(),em1.getEmail(),em1.getDigitalFingerPrintUrl(),em1.getJobPosition().name(),em1.getEmployeeStatus().name(),em1.getSalary());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el Empleado");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    public static boolean updateEmployee(String identification, String address, String phone, String email,double salary)throws SQLException {
        
        Employee em1 = new Employee(identification, address, phone, email, salary);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Employees SET address = ?, phone = ?, email = ?, salary = ? WHERE employ_id = ?";
        
        List<Object> parametros = Arrays.asList(em1.getAddress(), em1.getPhone(), em1.getEmail(),em1.getSalary(), em1.getIdentification());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar el Empleado");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    public static boolean deleteEmployee(String identification) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Employees WHERE employ_id = ?";
        
        List<Object> parametros = Arrays.asList(identification);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El Empleado fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el Empleado.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    public static Employee getEmployee(String identification) throws SQLException {
        
        Employee em1 = new Employee();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Employees WHERE employ_id = ?";
        List<Object> parametros = Arrays.asList(identification);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                em1.setIdentification(rs.getString("employ_id"));
                em1.setName(rs.getString("full_name"));
                em1.setAddress(rs.getString("address"));
                em1.setPhone(rs.getString("phone"));
                em1.setEmail(rs.getString("email"));
                em1.setDigitalFingerPrintUrl(rs.getString("digital_finger_print_url"));
                em1.setJobPosition(JobPosition.valueOf(rs.getString("job_position")));
                em1.setEmployeeStatus(EmployeeStatus.valueOf(rs.getString("employee_status")));
                em1.setSalary(rs.getDouble("salary"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Empleado: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return em1;
    }
    
     public static List<Employee> getEmployeeList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<Employee> employeelist = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Employees";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                Employee em1 = new Employee();
                em1.setIdentification(rs.getString("employ_id"));
                em1.setName(rs.getString("full_name"));
                em1.setAddress(rs.getString("address"));
                em1.setPhone(rs.getString("phone"));
                em1.setEmail(rs.getString("email"));
                em1.setDigitalFingerPrintUrl(rs.getString("digital_finger_print_url"));
                em1.setJobPosition(JobPosition.valueOf(rs.getString("job_position")));
                em1.setEmployeeStatus(EmployeeStatus.valueOf(rs.getString("employee_status")));
                em1.setSalary(rs.getDouble("salary"));
                
                employeelist.add(em1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Empleado: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return employeelist;
    }
    
    
    public static void showEmployeeList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<Employee> employees = getEmployeeList();
            System.out.println("~~~~~~~ LISTA DE EMPLEADOS ~~~~~~~");
            for(Employee em1 : employees){
                System.out.println("Empleado ID: " + em1.getIdentification());
                System.out.println("Full Name: " + em1.getName());
                System.out.println("Address: " + em1.getAddress());
                System.out.println("Phone: " + em1.getPhone());
                System.out.println("Email: " + em1.getEmail());
                System.out.println("Huella digital: " + em1.getDigitalFingerPrintUrl());
                System.out.println("Puesto de trabajo: " + em1.getJobPosition());
                System.out.println("Estado: " + em1.getEmployeeStatus());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los empleados: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
}


