/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum JobPosition {
    VETERINARIAN,
    RECEPTIONIST,
    VETERINARY_HEAD,
    ACCOUNTANT,
    LAWYER,
    GENERAL_ADMINISTRATOR,
    CLEANING;
    
    public static JobPosition chooseJobPosition(int chooseJobPosition) {
        switch(chooseJobPosition) {
            case 1: return JobPosition.VETERINARIAN;
            case 2: return JobPosition.RECEPTIONIST;
            case 3: return JobPosition.VETERINARY_HEAD;
            case 4: return JobPosition.ACCOUNTANT;
            case 5: return JobPosition.LAWYER;
            case 6: return JobPosition.GENERAL_ADMINISTRATOR;
            case 7: return JobPosition.CLEANING;
            default: throw new IllegalArgumentException("Job not available");
        }
    }
    
    
}
