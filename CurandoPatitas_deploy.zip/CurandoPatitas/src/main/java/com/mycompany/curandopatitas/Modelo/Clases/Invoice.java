/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */


import com.mycompany.curandopatitas.Modelo.Clases.InvoiceDetail;
import com.mycompany.curandopatitas.Modelo.Clases.InvoiceItem;
import com.mycompany.curandopatitas.Modelo.Clases.InvoiceService;
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import java.time.LocalDate;
import java.util.Map;


public class Invoice {
    private String CUFE; // Identificador único de la factura
    private Owner owner;
    private CompanyInformation companyInformation;
    private LocalDate Date;
    private double totalAmount;
    private double taxAmount;
    private String digitalStamp;
    private String qr_code_path;
    private boolean payed;

    public Invoice() {
    }

    public Invoice(String CUFE) {
        this.CUFE = CUFE;
    }

    public Invoice(String CUFE, boolean payed) {
        this.CUFE = CUFE;
        this.payed = payed;
    }
    
    

    public Invoice(String CUFE, Owner owner, CompanyInformation companyInformation, double taxAmount, String digitalStamp, String qr_code_path) {
        this.CUFE = CUFE;
        this.owner = owner;
        this.companyInformation = companyInformation;
        this.Date = LocalDate.now();
        this.totalAmount = 0.0;
        this.taxAmount = taxAmount;
        this.digitalStamp = digitalStamp;
        this.qr_code_path = qr_code_path;
        this.payed = true;
    }

    public String getCUFE() {
        return CUFE;
    }

    public void setCUFE(String CUFE) {
        this.CUFE = CUFE;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    public CompanyInformation getCompanyInformation() {
        return companyInformation;
    }

    public void setCompanyInformation(CompanyInformation companyInformation) {
        this.companyInformation = companyInformation;
    }

    public LocalDate getDate() {
        return Date;
    }

    public void setDate(LocalDate Date) {
        this.Date = Date;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getDigitalStamp() {
        return digitalStamp;
    }

    public void setDigitalStamp(String digitalStamp) {
        this.digitalStamp = digitalStamp;
    }

    public String getQr_code_path() {
        return qr_code_path;
    }

    public void setQr_code_path(String qr_code_path) {
        this.qr_code_path = qr_code_path;
    }

    public boolean isPayed() {
        return payed;
    }

    public void setPayed(boolean payed) {
        this.payed = payed;
    }
    
    public String getOwnerIdString() {
        return owner.getIdentification();
    }
    

    public String getNitString() {
        return companyInformation.getIdentification();
    }
    
    
}
