/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */


import com.mycompany.curandopatitas.Modelo.Clases.Day;
import com.mycompany.curandopatitas.Modelo.Clases.Employee;
import com.mycompany.curandopatitas.Modelo.Clases.Schedule;
import com.mycompany.curandopatitas.Modelo.Clases.Size;
import com.mycompany.curandopatitas.Modelo.Clases.Type;
import com.mycompany.curandopatitas.Modelo.Clases.Vaccination;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ScheduleController {
    //Create Schedule
    public static boolean createSchedule( Employee employId, Day day, LocalTime entryTime, LocalTime exitTime)throws SQLException{
        
        Schedule s1 = new Schedule(employId, day, entryTime, exitTime);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Schedule (employ_id, day, entry_time, exit_time) "
                + "VALUES (?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(s1.getEmployeeIdString(),s1.getDay().name(),s1.getEntryTime(),s1.getExitTime());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el horario");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    //Update Schedule
    
    public static boolean updateSchedule(Employee employId, Day day, LocalTime entryTime, LocalTime exitTime)throws SQLException {
        
        Schedule s1 = new Schedule(employId, day, entryTime, exitTime);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Schedule SET entry_time = ? , exit_time = ? "
                + "WHERE employ_id = ? AND day = ?";
        
        List<Object> parametros = Arrays.asList(
                s1.getEntryTime(),
                s1.getExitTime(),
                s1.getEmployeeIdString(),
                s1.getDay().name());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error el cargo adicional");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    
    //Get Objetc Schedule
    
    public static Schedule getSchedule(String employ_id,String day) throws SQLException {
        
        Schedule s1 = new Schedule();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Schedule WHERE employ_id = ? AND day = ?";
        List<Object> parametros = Arrays.asList(employ_id,day);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                s1.setEmployId(new Employee(rs.getString("employ_id")));
                s1.setDay(Day.valueOf(rs.getString("day")));
                s1.setEntryTime(rs.getTime("entry_time").toLocalTime());
                s1.setExitTime(rs.getTime("exit_time").toLocalTime());
                
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el horario: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return s1;
    }
    
    
    
    
    public static List<Schedule> getScheduleList(String employId) throws SQLException {
        CRUD.setConnection(Conexion.getConexion());
        List<Schedule> ScheduleList = new ArrayList<>();

        try {
            String obtener = "SELECT * FROM Schedule WHERE employ_id = ?";
            List<Object> params = new ArrayList<>();
            params.add(employId);

            ResultSet rs = CRUD.consultarBD1(obtener, params);
            while (rs.next()) {
                Schedule s1 = new Schedule();
                s1.setEmployId(new Employee(rs.getString("employ_id")));
                s1.setDay(Day.valueOf(rs.getString("day")));
                s1.setEntryTime(rs.getTime("entry_time").toLocalTime());
                s1.setExitTime(rs.getTime("exit_time").toLocalTime());

                ScheduleList.add(s1);
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el horario: " + ex.getMessage());
            throw ex;
        } finally {
            CRUD.cerrarConexion();
        }
        return ScheduleList;
    }

        //Show Aditional Charges List
    
    public static void showScheduleList(String employId){
        try {
            CRUD.setConnection(Conexion.getConexion());
            List<Schedule> scheduleList = getScheduleList(employId); 
            System.out.println("~~~~~~~~~~~~ LISTA DE HORARIOS ~~~~~~~~~~~~");
            for (Schedule s1 : scheduleList) {
                System.out.println("ID del Empleado: " + s1.getEmployeeIdString());
                System.out.println("Día: " + s1.getDay());
                System.out.println("Hora de Entrada: " + s1.getEntryTime());
                System.out.println("Hora de Salida: " + s1.getExitTime());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los horarios: " + e.getMessage());
            CRUD.cerrarConexion();
        }
    }
    
    
    
}

