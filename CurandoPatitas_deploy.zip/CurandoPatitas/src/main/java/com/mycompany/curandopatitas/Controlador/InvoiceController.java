/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */
import com.mycompany.curandopatitas.Modelo.Clases.CompanyInformation;
import com.mycompany.curandopatitas.Modelo.Clases.Inventory;
import com.mycompany.curandopatitas.Modelo.Clases.Invoice;
import com.mycompany.curandopatitas.Modelo.Clases.InvoiceDetail;
import com.mycompany.curandopatitas.Modelo.Clases.InvoiceItem;
import com.mycompany.curandopatitas.Modelo.Clases.InvoiceService;
import com.mycompany.curandopatitas.Modelo.Clases.Owner;
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class InvoiceController {

    // Create Invoice
    public static boolean createInvoice(String CUFE, Owner owner, CompanyInformation companyInformation, double taxAmount, String digitalStamp, String qr_code_path)throws SQLException{
        
        Invoice ow1 = new Invoice(CUFE, owner, companyInformation, taxAmount, digitalStamp, qr_code_path);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Invoices (CUFE, owner_id, NIT, invoice_date, total_amount, tax_amount, digital_stamp,qr_code_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(
                ow1.getCUFE(), 
                ow1.getOwnerIdString(),
                ow1.getNitString(),
                ow1.getDate(),
                ow1.getTotalAmount(),
                ow1.getTaxAmount(),
                ow1.getDigitalStamp(),
                ow1.getQr_code_path());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar factura");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    public static Invoice getInvoice(String CUFE) throws SQLException {
        
        Invoice ow1 = new Invoice();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Invoices WHERE CUFE = ?";
        List<Object> parametros = Arrays.asList(CUFE);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                ow1.setCUFE(rs.getString("CUFE"));
                ow1.setOwner(new Owner(rs.getString("owner_id")));
                ow1.setCompanyInformation(new CompanyInformation(rs.getString("NIT")));
                ow1.setDate(rs.getDate("invoice_date").toLocalDate());
                ow1.setTotalAmount(rs.getDouble("total_amount"));
                ow1.setTaxAmount(rs.getDouble("tax_amount"));
                ow1.setDigitalStamp(rs.getString("digital_stamp"));
                ow1.setQr_code_path(rs.getString("qr_code_path"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener factura: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return ow1;
    }
    
   
    
    public static List<Invoice> getInvoiceList(String CUFE) throws SQLException {
        CRUD.setConnection(Conexion.getConexion());
        List<Invoice> InvoiceList = new ArrayList<>();

        try {
            String obtener = "SELECT * FROM Invoices WHERE owner_id = ?";
            List<Object> params = new ArrayList<>();
            params.add(CUFE);

            ResultSet rs = CRUD.consultarBD1(obtener, params);
            while (rs.next()) {
                Invoice ow1 = new Invoice();
                ow1.setCUFE(rs.getString("CUFE"));
                ow1.setOwner(new Owner(rs.getString("owner_id")));
                ow1.setCompanyInformation(new CompanyInformation(rs.getString("NIT")));
                ow1.setDate(rs.getDate("invoice_date").toLocalDate());
                ow1.setTotalAmount(rs.getDouble("total_amount"));
                ow1.setTaxAmount(rs.getDouble("tax_amount"));
                ow1.setDigitalStamp(rs.getString("digital_stamp"));
                ow1.setQr_code_path(rs.getString("qr_code_path"));

                InvoiceList.add(ow1);
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener facturas: " + ex.getMessage());
            throw ex;
        } finally {
            CRUD.cerrarConexion();
        }
        return InvoiceList;
    }
    
    
    public static void showInvoiceList(String CUFE){
        try {
            CRUD.setConnection(Conexion.getConexion());
            List<Invoice> invoiceList = getInvoiceList(CUFE); 
            System.out.println("~~~~~~~~~~~~ LISTA FACTURAS ~~~~~~~~~~~~");
            for (Invoice s1 : invoiceList) {
                System.out.println("CUFE: " + s1.getCUFE());
                System.out.println("Id Dueno: " + s1.getOwnerIdString());
                System.out.println("NIT: " + s1.getNitString());
                System.out.println("Fecha: " + s1.getDate());
                System.out.println("Valor total: " + s1.getTotalAmount());
                System.out.println("Taxes: " + s1.getTaxAmount());
                System.out.println("Stampa digital: " + s1.getDigitalStamp());
                System.out.println("Code path: " + s1.getQr_code_path());
                
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener facturas: " + e.getMessage());
            CRUD.cerrarConexion();
        }
    }

}


