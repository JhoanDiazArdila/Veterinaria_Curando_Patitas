/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */
import com.mycompany.curandopatitas.Modelo.Clases.Day;
import com.mycompany.curandopatitas.Modelo.Clases.Employee;
import com.mycompany.curandopatitas.Modelo.Clases.Inventory;
import com.mycompany.curandopatitas.Modelo.Clases.Invoice;
import com.mycompany.curandopatitas.Modelo.Clases.InvoiceItem;
import com.mycompany.curandopatitas.Modelo.Clases.Size;
import com.mycompany.curandopatitas.Modelo.Clases.Type;
import com.mycompany.curandopatitas.Modelo.Clases.Vaccination;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Arrays;
import java.util.List;




public class InvoiceItemController {
    public static boolean createInvoiceItem( Invoice invoice, Inventory item, String description, int quantity)throws SQLException{
        
        InvoiceItem s1 = new InvoiceItem(invoice, item, description, quantity);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Invoice_item (item_id, CUFE, description, quantity, total_price) "
                + "VALUES (?, ?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(item.getItemId(),invoice.getCUFE(),s1.getDescription(),s1.getQuantity(),s1.getTotalPrice());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el horario");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
}

