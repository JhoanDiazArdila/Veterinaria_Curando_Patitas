/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

import java.time.LocalTime;

/**
 *
 * @author jhoan
 */
public class Schedule {
    
    private int scheduleId;
    private Employee employId;
    private Day day;
    private LocalTime entryTime;
    private LocalTime exitTime ;

    // CONSTRUCTOR
    
    public Schedule() {}

    public Schedule(int scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Schedule(int scheduleId, LocalTime entryTime, LocalTime exitTime) {
        this.scheduleId = scheduleId;
        this.entryTime = entryTime;
        this.exitTime = exitTime;
    }

    public Schedule(Employee employId, Day day, LocalTime entryTime, LocalTime exitTime) {
        this.employId = employId;
        this.day = day;
        this.entryTime = entryTime;
        this.exitTime = exitTime;
    }

    
    // GETTERS AND SETTERS
    
    public int getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(int scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Employee getEmployId() {
        return employId;
    }

    public void setEmployId(Employee employId) {
        this.employId = employId;
    }

    public Day getDay() {
        return day;
    }

    public void setDay(Day day) {
        this.day = day;
    }

    public LocalTime getEntryTime() {
        return entryTime;
    }

    public void setEntryTime(LocalTime entryTime) {
        this.entryTime = entryTime;
    }

    public LocalTime getExitTime() {
        return exitTime;
    }

    public void setExitTime(LocalTime exitTime) {
        this.exitTime = exitTime;
    }
    
    public String getIdString() {
        return employId.getIdentification();
    }
    
    public String getEmployeeIdString() {
        return employId.getIdentification();
    }
    
    public String setEmployeeIdString(String employe_id) {
        return employId.getIdentification();
    }
    
    
    
}
