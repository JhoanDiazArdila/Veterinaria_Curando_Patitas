/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class CompanyInformation extends User {

    
    public CompanyInformation(){}
    
    public CompanyInformation(String identification){
        this.identification = identification;
    }
    
    public CompanyInformation(String identification, String phone, String email, String address){
        this.identification = identification;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }
    
    public CompanyInformation(String identification, String name, String phone, String email, String address) {
        super(identification, name, phone, email, address);
    }

    
    
    
    @Override
    public String toString() {
        return "~~~~~~~~ Company Information ~~~~~~~~" + 
                "\nNIT: "+ this.identification+
                "\nName: " + this.name +
                "\nAddress: " + this.address +
                "\nPhone: "+ this.phone+
                "\nEmail: "+ this.email +
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }

 
    
    
    
}
