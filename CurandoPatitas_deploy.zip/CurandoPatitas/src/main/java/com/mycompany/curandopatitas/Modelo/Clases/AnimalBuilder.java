



package com.mycompany.curandopatitas.Modelo.Clases;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;

/**
 *
 * @author jhoan
 * @param <T>
 */

public class AnimalBuilder<T extends Animal> {
    
    private T animal;
    
    public AnimalBuilder(Class<T> clazz){
        try {
            this.animal = clazz.getDeclaredConstructor().newInstance();
        } catch (IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException e) {
            throw new RuntimeException("Error creating animal instance", e);
        }

    }
    
    public AnimalBuilder<T> setPetId(int petId) {
        this.animal.petId = petId;
        return this;
    }

    public AnimalBuilder<T> setOwnerId(Owner ownerId) {
        this.animal.owner = ownerId;
        return this;
    }

    public AnimalBuilder<T> setName(String name) {
        this.animal.name = name;
        return this;
    }

    public AnimalBuilder<T> setBehavior(Behavior behavior) {
        this.animal.behavior = behavior;
        return this;
    }

    public AnimalBuilder<T> setRace(String subType) {
        if (this.animal instanceof Mammal mammal) {
            mammal.setBreed(subType);
        } else if(this.animal instanceof Reptile reptile){
            reptile.setSubType(subType);
        } else if(this.animal instanceof Bird bird){
            bird.setVariety(subType);
        }else {
            throw new IllegalArgumentException("The animal is not a Allowed, subType cannot be set.");
        }
        return this;
    }
   
    
    public AnimalBuilder<T> setAge(int age) {
        this.animal.age = age;
        return this;
    }

    public AnimalBuilder<T> setBirthdate(LocalDate birthdate) {
        this.animal.birthdate = birthdate;
        return this;
    }
    
    public AnimalBuilder<T> setSex(Sex sex) {
        this.animal.sex = sex;
        return this;
    }

    public AnimalBuilder<T> setMicrochipNumber(String microchipNumber) {
        this.animal.microchipNumber = microchipNumber;
        return this;
    }

    public AnimalBuilder<T> setPhotoPath(String photoPath) {
        this.animal.photoPath = photoPath;
        return this;
    }

    public AnimalBuilder<T> setWeight(Double weight) {
        this.animal.weight = weight;
        return this;
    }

    public AnimalBuilder<T> setSize(Size size) {
        this.animal.size = size;
        return this;
    }

    public AnimalBuilder<T> setAllergies(String allergies) {
        this.animal.allergies = allergies;
        return this;
    }

    public AnimalBuilder<T> setMedicalConditions(String medicalConditions) {
        this.animal.medicalConditions = medicalConditions;
        return this;
    }
    
    public T build() {
        return this.animal;
    }

    public AnimalBuilder<T> setBreed(String breed){
        this.animal.setBreed(breed);
        return this;
    }

//    public AnimalBuilder<T> setSpicie(String spicie){
//        this.animal.setSpicie(spicie);
//        return this;
//    }
    
    
}
