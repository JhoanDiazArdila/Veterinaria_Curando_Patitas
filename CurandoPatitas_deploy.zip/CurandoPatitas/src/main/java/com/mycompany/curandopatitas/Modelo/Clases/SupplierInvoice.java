/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;


import java.util.*;
import java.time.LocalDate; 
/**
 *
 * @author jhoan
 */
public class SupplierInvoice {
    
    private int suplplierInvoiceId;
    private Supplier suplier;
    private LocalDate invoiceDate;
    private Double taxAmount;
    private Double totalAmount;
    
    
    
    // CONSTRUCTOR
    public SupplierInvoice() {}

    public SupplierInvoice(int suplplierInvoiceId, Supplier suplier, LocalDate invoiceDate, Double taxAmount, Double totalAmount) {
        
        this.suplplierInvoiceId = suplplierInvoiceId;
        this.suplier = suplier;
        this.invoiceDate = invoiceDate;
        this.taxAmount = taxAmount;
        this.totalAmount = totalAmount;
    }

    public int getSuplplierInvoiceId() {
        return suplplierInvoiceId;
    }

    public void setSuplplierInvoiceId(int suplplierInvoiceId) {
        this.suplplierInvoiceId = suplplierInvoiceId;
    }

    public Supplier getSuplier() {
        return suplier;
    }

    public void setSuplier(Supplier suplier) {
        this.suplier = suplier;
    }

    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(Double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public String toString() {
        return "Supplier Invoice" + 
                "\nSuplplier Invoice Id:" + suplplierInvoiceId + 
                "\nSuplier: " + suplier + 
                "\nInvoiceDate: " + invoiceDate + 
                "\nTaxAmount: " + taxAmount + 
                "\nTotalAmount: " + totalAmount + 
                "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }

    
    
    
    
    
    
    
    
}
