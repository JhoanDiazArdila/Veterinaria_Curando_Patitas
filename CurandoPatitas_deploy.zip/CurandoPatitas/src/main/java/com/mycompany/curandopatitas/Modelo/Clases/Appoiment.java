



package com.mycompany.curandopatitas.Modelo.Clases;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 *
 * @author jhoan
 */
public class Appoiment {
    private int appoimentId;
    private Service serviceId;
    private Employee employId;
    private Animal petId;
    private LocalDateTime entryDateTime;
    private LocalDateTime exitDateTime;
    private String visitReason;
    private String diagnosis;
    private String recomendations;
    private String prescriptionMedicines;
    private AppointmentStatus status;
    
    
    // Contstructors
    
    public Appoiment(){}
    
    public Appoiment(int appoimentId){
        this.appoimentId = appoimentId;
    }
    
    public Appoiment(int appoimentId, Employee employId, 
            LocalDateTime entryDateTime, LocalDateTime exitDateTime,AppointmentStatus status){
        
        this.appoimentId = appoimentId;
        this.employId = employId;
        this.entryDateTime = entryDateTime;
        this.exitDateTime = exitDateTime;
        this.status = status;
    }

    public Appoiment(Service serviceId, Employee employId, Animal petId, 
            LocalDateTime entryDateTime, LocalDateTime exitDateTime, String visitReason, 
            String diagnosis, String recomendations, String prescriptionMedicines, 
            AppointmentStatus status) {
        
        this.serviceId = serviceId;
        this.employId = employId;
        this.petId = petId;
        this.entryDateTime = entryDateTime;
        this.exitDateTime = exitDateTime;
        this.visitReason = visitReason;
        this.diagnosis = diagnosis;
        this.recomendations = recomendations;
        this.prescriptionMedicines = prescriptionMedicines;
        this.status = status;
    }
    

    
    // GETTERS AND SETTERS

    public int getAppoimentId() {
        return appoimentId;
    }

    public void setAppoimentId(int appoimentId) {
        this.appoimentId = appoimentId;
    }

    public Service getServiceId() {
        return serviceId;
    }
 // ---------------------------------------------
    public int getServiceIdString() {
        return serviceId.getServiceId();
    }
 // ---------------------------------------------
    
    public void setServiceId(Service serviceId) {
        this.serviceId = serviceId;
    }

    public Employee getEmployId() {
        return employId;
    }
  // ---------------------------------------------
    public String getEmployIdString() {
        return employId.getIdentification();
    }
 // ---------------------------------------------   
    
    
    public void setEmployId(Employee employId) {
        this.employId = employId;
    }

    public Animal getPetId() {
        return petId;
    }
 // ---------------------------------------------
    public int getPetIdString() {
        return petId.getPetId();
    }
 // ---------------------------------------------
    public void setPetId(Animal petId) {
        this.petId = petId;
    }

    public LocalDateTime getEntryDateTime() {
        return entryDateTime;
    }
  // ---------------------------------------------  
    public Timestamp getEntryDateTimeAsTimestamp() {
        return entryDateTime != null ? Timestamp.valueOf(entryDateTime) : null;
    }
    
    public Timestamp getExitDateTimeAsTimestamp() {
        return exitDateTime != null ? Timestamp.valueOf(entryDateTime) : null;
    }
    
  // ---------------------------------------------
    public void setEntryDateTime(LocalDateTime entryDateTime) {
        this.entryDateTime = entryDateTime;
    }

    public LocalDateTime getExitDateTime() {
        return exitDateTime;
    }

    public void setExitDateTime(LocalDateTime exitDateTime) {
        this.exitDateTime = exitDateTime;
    }

    public String getVisitReason() {
        return visitReason;
    }

    public void setVisitReason(String visitReason) {
        this.visitReason = visitReason;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getRecomendations() {
        return recomendations;
    }

    public void setRecomendations(String recomendations) {
        this.recomendations = recomendations;
    }

    public String getPrescriptionMedicines() {
        return prescriptionMedicines;
    }

    public void setPrescriptionMedicines(String prescriptionMedicines) {
        this.prescriptionMedicines = prescriptionMedicines;
    }

    public AppointmentStatus getStatus() {
        return status;
    }

    public void setStatus(AppointmentStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "~~~~~~~~~~~~~ Appoiment ~~~~~~~~~~~~~" + 
                "\nAppoiment Id: " + appoimentId + 
                "\nService Id: " + serviceId + 
                "\nEmploy Id: " + employId + 
                "\nPet Id: " + petId + 
                "\nEntry Date Time: " + entryDateTime + 
                "\nExit Date Time: " + exitDateTime + 
                "\nVisit Reason: " + visitReason + 
                "\nDiagnosis: " + diagnosis + 
                "\nRecomendations: " + recomendations + 
                "\nPrescription Medicines: " + prescriptionMedicines + 
                "\nStatus=" + status + 
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }

    
    
    
    
    
    
}
