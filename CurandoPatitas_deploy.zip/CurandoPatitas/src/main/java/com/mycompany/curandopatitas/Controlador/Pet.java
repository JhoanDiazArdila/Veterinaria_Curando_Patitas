


package com.mycompany.curandopatitas.Controlador;


import com.mycompany.curandopatitas.Modelo.Clases.Animal;
import com.mycompany.curandopatitas.Modelo.Clases.AnimalBuilder;
import com.mycompany.curandopatitas.Modelo.Clases.Behavior;
import com.mycompany.curandopatitas.Modelo.Clases.Owner;
import com.mycompany.curandopatitas.Modelo.Clases.Sex;
import com.mycompany.curandopatitas.Modelo.Clases.Size;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.*;
import java.util.List;


/**
 *
 * @author jhoan
 */
public class Pet {
    
    
    public static boolean createPet(
            Owner owner, String name, Behavior behavior, String breed, 
            int age, LocalDate birthdate, Sex sex, String microchipNumber, 
            String photoPath, Double weight, Size size, String allergies, 
            String medicalConditions, String type) throws SQLException {
        
        
        try{
            // Intentar cargar la clase dinámicamente
            Class<?> animalClass = Class.forName("com.mycompany.curandopatitas.Modelo.Clases." + type);
            
            AnimalBuilder builder = new AnimalBuilder((Class<? extends Animal>) animalClass)
                .setOwnerId(owner)
                .setName(name)
                .setBehavior(behavior)
                .setAge(age)
                .setBirthdate(birthdate)
                .setSex(sex)
                .setMicrochipNumber(microchipNumber)
                .setPhotoPath(photoPath)
                .setWeight(weight)
                .setSize(size)
                .setAllergies(allergies)
                .setMedicalConditions(medicalConditions)
                .setBreed(breed);
    
            Animal a1 = builder.build();

            
        // Connection Established   
            CRUD.setConnection(Conexion.getConexion());

        //  SQL REQUEST
            String insercion = "INSERT INTO Pets (" +
                 "owner_id, name, behavior, species, type, breed, age, birthdate, sex, " +
                 "microchip_number, photo_path, weight, size, allergies, medical_conditions" +
                 ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
//            System.out.println(a1.getBehavior());
            
            List<Object> parametros = Arrays.asList(
                a1.getOwnerId(),a1.getName(),a1.getBehavior().name(),a1.getSpicie(),a1.getType(), 
                a1.getBreed(),a1.getAge(), a1.getBirthdate(),a1.getSex().name(),
                a1.getMicrochipNumber(),a1.getPhotoPath(),a1.getWeight(),
                a1.getSize().name(),a1.getAllergies(),a1.getMedicalConditions());
        
            try{
         // auto-commit OFF
                if(CRUD.setAutoCommitBD(false)){
                  // Llamar metodo de insertar
                    if(CRUD.insertarBD1(insercion, parametros)){
                        System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                    } else {
                        System.out.println("Error al registrar el Mascota");
                        CRUD.rollbackBD();  
                    }
                }
            }catch (Exception ex) {
                System.out.println("Error en la transacción: " + ex.getMessage());
                CRUD.rollbackBD(); 
                throw ex; 
            } finally {
                // Restablecer auto-commit a true
                CRUD.setAutoCommitBD(true);
                CRUD.cerrarConexion();  
            }
            return false;            
            
        } catch (ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
        

 // ----------------------------------------------------
    
    // CHANGE OF OWNER AND UPDATE AT THE SAME TIME
    
    public static boolean updatePet(int pet_id, Owner owner, String name, Double weight, String photo_path) throws SQLException {
        try {
            // Obtener el objeto `Animal` existente en la base de datos usando `getPet`
            Animal existingPet = getPet(pet_id);

            if (existingPet == null) {
                System.out.println("No se encontró una mascota con el ID proporcionado.");
                return false;
            }

            // Crear una instancia del builder con la clase del animal recuperado
            AnimalBuilder builder = new AnimalBuilder(existingPet.getClass())
                    .setPetId(pet_id) // ID de la mascota no cambia
                    .setOwnerId(owner) // Actualizar propietario
                    .setName(name) // Actualizar nombre
                    .setWeight(weight) // Actualizar peso
                    .setPhotoPath(photo_path); // Actualizar foto

            // Copiar los valores restantes desde el objeto existente
            builder.setBehavior(existingPet.getBehavior())
                   .setBreed(existingPet.getBreed())
                   .setAge(existingPet.getAge())
                   .setBirthdate(existingPet.getBirthdate())
                   .setSex(existingPet.getSex())
                   .setMicrochipNumber(existingPet.getMicrochipNumber())
                   .setSize(existingPet.getSize())
                   .setAllergies(existingPet.getAllergies())
                   .setMedicalConditions(existingPet.getMedicalConditions());

            // Construir el nuevo objeto `Animal` actualizado
            Animal updatedPet = builder.build();

            // Conectar y preparar la consulta de actualización
            CRUD.setConnection(Conexion.getConexion());

            String updateQuery = "UPDATE Pets SET owner_id = ?, name = ?, photo_path = ?, weight = ? WHERE pet_id = ?";
            List<Object> parametros = Arrays.asList(
                updatedPet.getOwnerId(),
                updatedPet.getName(),
                updatedPet.getPhotoPath(),
                updatedPet.getWeight(),
                updatedPet.getPetId()
            );

            try {
                // Manejo de transacción
                if (CRUD.setAutoCommitBD(false)) {
                    if (CRUD.actualizarBD1(updateQuery, parametros)) {
                        System.out.println("Actualización exitosa!");
                        CRUD.commitBD();
                        return true;
                    } else {
                        System.out.println("Error al realizar la actualización.");
                        CRUD.rollbackBD();
                    }
                }
            } catch (Exception ex) {
                System.err.println("Error en la transacción: " + ex.getMessage());
                CRUD.rollbackBD();
                throw ex; // Relanzar la excepción
            } finally {
                CRUD.setAutoCommitBD(true);
                CRUD.cerrarConexion();
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return false;
    }

 // ----------------------------------------------------   
    
    public static boolean deletePet(int pet_id) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Pets WHERE pet_id = ?";
        // Lista de parámetros
        List<Object> parametros = Arrays.asList(pet_id);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("La Mascota fue eliminada exitosamente.");
                    CRUD.commitBD(); // Confirmar la operacion
                    return true;
                }else{
                    System.out.println("Error al eliminar Mascota.");
                    CRUD.rollbackBD(); // Revertir la transacción en caso de error
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); // Revertir en caso de excepción
            throw ex; // Relanzar la excepción para manejarla en capas superiores
        } finally {
            // Restablecer auto-commit y cerrar la conexión
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false; // Retorna false si algo falla        
    }
    
    
    // ----------------------------------------------------
    public static Animal getPet(int pet_id) throws SQLException {
        try {
            // Configuración de la conexión y la consulta SQL inicial para obtener el tipo
            CRUD.setConnection(Conexion.getConexion());
            String getType = "SELECT type FROM Pets WHERE pet_id = ? ";
            List<Object> parameterType = Arrays.asList(pet_id);

            String type = null;

            try (ResultSet rsTipo = CRUD.consultarBD1(getType, parameterType)) {
                if (rsTipo.next()) {
                    type = rsTipo.getString("type");
                } else {
                    System.out.println("No se encontró una mascota con el ID proporcionado.");
                    return null;
                }
            }

            // Cargar la clase del animal dinámicamente usando el tipo obtenido
            Class<?> animalClass = Class.forName("com.mycompany.curandopatitas.Modelo.Clases." + type);

            // Crear una instancia del AnimalBuilder
            AnimalBuilder builder = new AnimalBuilder((Class<? extends Animal>) animalClass);

            // Consulta SQL para obtener los detalles de la mascota
            String getDetails = "SELECT * FROM Pets WHERE pet_id = ?";
            List<Object> parametrosDetalles = Arrays.asList(pet_id);

            Animal animal = null;

            try (ResultSet rsDetails = CRUD.consultarBD1(getDetails, parametrosDetalles)) {
                if (rsDetails.next()) {
                    // Usar el builder para asignar los valores del ResultSet al objeto
                    builder.setPetId(rsDetails.getInt("id_pet"))
                           .setOwnerId(new Owner(rsDetails.getString("owner_id"))) 
                           .setName(rsDetails.getString("name"))
                           .setBehavior(Behavior.valueOf(rsDetails.getString("behavior")))
                           .setBreed(rsDetails.getString("breed"))
                           .setAge(rsDetails.getInt("age"))
                           .setBirthdate(rsDetails.getDate("birthdate").toLocalDate())
                           .setSex(Sex.valueOf(rsDetails.getString("sex")))
                           .setMicrochipNumber(rsDetails.getString("microchip_number"))
                           .setPhotoPath(rsDetails.getString("photo_path"))
                           .setWeight(rsDetails.getDouble("weight"))
                           .setSize(Size.valueOf(rsDetails.getString("size")))
                           .setAllergies(rsDetails.getString("allergies"))
                           .setMedicalConditions(rsDetails.getString("medical_conditions"));

                    // Build Animal Object
                    animal = builder.build();
                }
            }

            return animal; // Return the Animal Build

        } catch (ClassNotFoundException e) {
            System.err.println("Error: Clase no encontrada - " + e.getMessage());
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            // Cerrar la conexión
            CRUD.cerrarConexion();
        }
    }

    // ----------------------------------------------------
    
    
    public static ArrayList<Animal> getAnimalList() throws SQLException{
        CRUD.setConnection(Conexion.getConexion());
        ArrayList<Animal> animalList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Pets";
            ResultSet rsDetails = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rsDetails.next()){
                
                String type = rsDetails.getString("type");
                try{
                    Class<?> animalClass = Class.forName("com.mycompany.curandopatitas.Modelo.Clases." + type);
                    
                    AnimalBuilder builder = new AnimalBuilder((Class<? extends Animal>) animalClass)
                           .setPetId(rsDetails.getInt("pet_id"))
                           .setOwnerId(new Owner(rsDetails.getString("owner_id"))) 
                           .setName(rsDetails.getString("name"))
                           .setBehavior(Behavior.valueOf(rsDetails.getString("behavior")))
                           .setBreed(rsDetails.getString("breed"))
                           .setAge(rsDetails.getInt("age"))
                           .setBirthdate(rsDetails.getDate("birthdate").toLocalDate())
                           .setSex(Sex.valueOf(rsDetails.getString("sex")))
                           .setMicrochipNumber(rsDetails.getString("microchip_number"))
                           .setPhotoPath(rsDetails.getString("photo_path"))
                           .setWeight(rsDetails.getDouble("weight"))
                           .setSize(Size.valueOf(rsDetails.getString("size")))
                           .setAllergies(rsDetails.getString("allergies"))
                           .setMedicalConditions(rsDetails.getString("medical_conditions"));
             // Construir el objeto Animal
                    Animal animal = builder.build();
                    animalList.add(animal);
                } catch (ClassNotFoundException e) {
                    System.err.println("Error: Clase no encontrada para el tipo " + type + " - " + e.getMessage());
                    // Continuar con el siguiente registro
                }
            }

            rsDetails.close(); // Cerrar el ResultSet

        } catch (SQLException ex) {
            System.out.println("Error al obtener la lista de animales: " + ex.getMessage());
            throw ex; // Relanzar excepción para manejarla en capas superiores
        } finally {
            // Cerrar la conexión
            CRUD.cerrarConexion();
        }

        return animalList;
    }
                
      
    
    public static void showAnimalList(){
        try {
            CRUD.setConnection(Conexion.getConexion());
            ArrayList<Animal> animales = getAnimalList();
            
            System.out.println("~~~~~~~ LISTA DE ANIMALES ~~~~~~~");
            for (Animal animal : animales) {
                System.out.println("Mascota ID: " + animal.getPetId());
                System.out.println("Nombre: " + animal.getName());
                System.out.println("Dueño ID: " + animal.getOwnerId());
                System.out.println("Comportamiento: " + animal.getBehavior());
                System.out.println("Especie: " + animal.getSpicie()); 
                System.out.println("Sub-especie: " + animal.getType()); 
                System.out.println("Raza: " + animal.getBreed());
                System.out.println("Edad: " + animal.getAge());
                System.out.println("Fecha de nacimiento: " + animal.getBirthdate());
                System.out.println("Sexo: " + animal.getSex());
                System.out.println("Número de microchip: " + animal.getMicrochipNumber());
                System.out.println("Peso: " + animal.getWeight() + " kg");
                System.out.println("Tamaño: " + animal.getSize());
                System.out.println("Alergias: " + animal.getAllergies());
                System.out.println("Condiciones médicas: " + animal.getMedicalConditions());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener la lista de animales: " + e.getMessage());
        } finally {
            // Cerrar la conexión, independientemente del éxito o error
            CRUD.cerrarConexion();
        }
    }

    

    private static boolean hasField(Class<?> clazz, String fieldName){
        try{
            clazz.getDeclaredField(fieldName);
            return true;
        } catch (NoSuchFieldException e){
            return false;
        }
    }
    
    
    
    // SHOW ANIMALS FOR ADOPTION OR ANIMALS BY OWNER
    public static void showAnimalListByOwner(String owner_id) throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        ArrayList<Animal> animalList = new ArrayList<>();
        
        try{
            String obtener;
            List<Object> parameterType = new ArrayList<>();
            
            if ("null".equals(owner_id)) {
                obtener = "SELECT * FROM Pets WHERE owner_id IS NULL";
            } else {
                obtener = "SELECT * FROM Pets WHERE owner_id = ?";
                parameterType.add(owner_id);
            }
            
            ResultSet rsDetails = CRUD.consultarBD1(obtener, parameterType);
            while(rsDetails.next()){
                
                String type = rsDetails.getString("type");
                try{
                    Class<?> animalClass = Class.forName("com.mycompany.curandopatitas.Modelo.Clases." + type);
                    
                    AnimalBuilder builder = new AnimalBuilder((Class<? extends Animal>) animalClass)
                           .setPetId(rsDetails.getInt("pet_id"))
                           .setOwnerId(new Owner(rsDetails.getString("owner_id"))) 
                           .setName(rsDetails.getString("name"))
                           .setBehavior(Behavior.valueOf(rsDetails.getString("behavior")))
                           .setBreed(rsDetails.getString("breed"))
                           .setAge(rsDetails.getInt("age"))
                           .setBirthdate(rsDetails.getDate("birthdate").toLocalDate())
                           .setSex(Sex.valueOf(rsDetails.getString("sex")))
                           .setMicrochipNumber(rsDetails.getString("microchip_number"))
                           .setPhotoPath(rsDetails.getString("photo_path"))
                           .setWeight(rsDetails.getDouble("weight"))
                           .setSize(Size.valueOf(rsDetails.getString("size")))
                           .setAllergies(rsDetails.getString("allergies"))
                           .setMedicalConditions(rsDetails.getString("medical_conditions"));
             // Construir el objeto Animal
                    Animal animal = builder.build();
                    animalList.add(animal);
                } catch (ClassNotFoundException e) {
                    System.err.println("Error: Clase no encontrada para el tipo " + type + " - " + e.getMessage());
                    // Continuar con el siguiente registro
                }
            }

            rsDetails.close(); // Cerrar el ResultSet

        } catch (SQLException ex) {
            System.out.println("Error al obtener la lista de animales: " + ex.getMessage());
            throw ex; // Relanzar excepción para manejarla en capas superiores
        } finally {
            // Cerrar la conexión
            CRUD.cerrarConexion();
        }
        
        System.out.println("~~~~~~~ LISTA DE MASCOTAS DEL DUEÑO ~~~~~~~");
            for (Animal animal : animalList) {
                System.out.println("Mascota ID: " + animal.getPetId());
                System.out.println("Nombre: " + animal.getName());
                System.out.println("Dueño ID: " + animal.getOwnerId());
                System.out.println("Comportamiento: " + animal.getBehavior());
                System.out.println("Especie: " + animal.getSpicie()); 
                System.out.println("Sub-especie: " + animal.getType()); 
                System.out.println("Raza: " + animal.getBreed());
                System.out.println("Edad: " + animal.getAge());
                System.out.println("Fecha de nacimiento: " + animal.getBirthdate());
                System.out.println("Sexo: " + animal.getSex());
                System.out.println("Número de microchip: " + animal.getMicrochipNumber());
                System.out.println("Peso: " + animal.getWeight() + " kg");
                System.out.println("Tamaño: " + animal.getSize());
                System.out.println("Alergias: " + animal.getAllergies());
                System.out.println("Condiciones médicas: " + animal.getMedicalConditions());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
    }
    
    

    
    
    
}
