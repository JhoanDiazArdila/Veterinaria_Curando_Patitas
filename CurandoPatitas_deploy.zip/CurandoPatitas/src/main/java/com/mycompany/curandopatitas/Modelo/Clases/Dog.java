



package com.mycompany.curandopatitas.Modelo.Clases;


import java.time.LocalDate;

/**
 *
 * @author jhoan
 */
public class Dog extends Mammal{

//    protected String breed;
    
    // CONSTRUCTOR
    
    public Dog() {}
    
    public Dog(int petId){
        this.petId = petId;
    }
    
    public Dog(int pet_id, Owner owner, String name, Double weigth, String photo_path){
        this.owner = owner;
        this.name = name;
        this.weight = weigth;
        this.photoPath = photo_path;
        
    }
    public Dog(String breed, Owner owner, String name, Behavior behavior, 
            int age, LocalDate birthdate, Sex sex, String microchipNumber, 
            String photoPath, Double weight, Size size, String allergies, 
            String medicalConditions) {
        
        super(breed, owner, name, behavior, age, birthdate, sex, 
                microchipNumber, photoPath, weight, size, allergies, 
                medicalConditions);
        
    }
    
    
    
    
    @Override
    public String getType(){
        return "DOG";
    }
    
    
    @Override
    public String toString() {
        return "~~~~~~~~~~ DOG ~~~~~~~~~~" + 
                "\nPet Id:" + petId +
                "\nName: " + name + 
                "\nSex: " + sex + 
                "\nBehavior: " + behavior +
                "\nWeight: " + weight + 
                "\nSize:" + size + 
                "\nAge: " + age + 
                "\nBirthdate: " + birthdate + 
                "\nSpecie: " + getSpicie()+
                "\nSub Specie: " + getType()+
                "\nBreed: " + breed+
                "\nMicrochip Number: " + microchipNumber + 
                "\nPhoto Path: " + photoPath +
                "\nAllergies: " + allergies + 
                "\nMedical Conditions: " + medicalConditions +
                "\n" + owner ;
    }
    
    
}
