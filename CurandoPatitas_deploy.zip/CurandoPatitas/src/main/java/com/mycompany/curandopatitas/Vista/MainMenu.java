/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Vista;

/**
 *
 * @author jhoan
 */

import java.util.*;



public class MainMenu {
    private static Scanner scanner = new Scanner(System.in);
    
    
    public static void main(String[] args) {
        OUTER:
        while (true) {
            System.out.println("\n~~~ Sistema de Gestión de Veterinaria ~~~");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("\n~~~~~~~ Bienvenido a Curando Patitas ~~~~~~~");
            System.out.println("1. Menu Veterinario");
            System.out.println("2. Menu Recepcion");
            System.out.println("3. Menu Administrador");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            
            int opcion = scanner.nextInt();
            
            
            switch (opcion) {
                case 1 -> MenuAdmin.mostrarMenu();
                case 2 -> MenuAdmin.mostrarMenu();
                case 3 -> MenuAdmin.mostrarMenu();
                case 0 -> {
                    System.out.println("Saliendo...");
                    break OUTER;
                }
                default -> System.out.println("Opción no válida.");
            }
        }
    }
    
    
}
