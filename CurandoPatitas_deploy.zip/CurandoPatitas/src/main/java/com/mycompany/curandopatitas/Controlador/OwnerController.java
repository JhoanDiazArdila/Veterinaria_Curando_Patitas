/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

import com.mycompany.curandopatitas.Modelo.Clases.Owner;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author jhoan
 */
public class OwnerController {
    
    
    public static boolean createOwner(String emergencyName, String emergencyContact, 
            String identification, String name, String phone, String email, String address)throws SQLException{
        
        Owner ow1 = new Owner(emergencyName, emergencyContact, identification, name, phone, email, address);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Owners (owner_id, full_name, address, phone, email, emergency_contact_name, emergency_contact_phone) VALUES (?, ?, ?, ?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(ow1.getIdentification(), ow1.getName(),ow1.getAddress(),
                ow1.getPhone(),ow1.getEmail(),ow1.getEmergencyName(),ow1.getEmergencyContact());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el Dueño");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    
    public static boolean updateOwner(String identification, String address, String phone, String email)throws SQLException {
        
        Owner ow1 = new Owner(identification, address, phone, email);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Owners SET address = ?, phone = ?, email = ? WHERE owner_id = ?";
        
        List<Object> parametros = Arrays.asList(ow1.getAddress(), ow1.getPhone(), ow1.getEmail(), ow1.getIdentification());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar el Dueño");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    
    
    public static boolean deleteOwner(String identification) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Owners WHERE owner_id = ?";
        
        List<Object> parametros = Arrays.asList(identification);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El Dueño fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el Dueño.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    
    
    public static Owner getOwner(String identification) throws SQLException {
        
        Owner ow1 = new Owner();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Owners WHERE owner_id = ?";
        List<Object> parametros = Arrays.asList(identification);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                ow1.setIdentification(rs.getString("owner_id"));
                ow1.setName(rs.getString("full_name"));
                ow1.setAddress(rs.getString("address"));
                ow1.setPhone(rs.getString("phone"));
                ow1.setEmail(rs.getString("email"));
                ow1.setEmergencyName(rs.getString("emergency_contact_name"));
                ow1.setEmergencyContact(rs.getString("emergency_contact_phone"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Dueño: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return ow1;
    }
    
    
    public static List<Owner> getOwnerList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<Owner> ownerList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Owners";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                Owner ow1 = new Owner();
                ow1.setIdentification(rs.getString("owner_id"));
                ow1.setName(rs.getString("full_name"));
                ow1.setAddress(rs.getString("address"));
                ow1.setPhone(rs.getString("phone"));
                ow1.setEmail(rs.getString("email"));
                ow1.setEmergencyName(rs.getString("emergency_contact_name"));
                ow1.setEmergencyContact(rs.getString("emergency_contact_phone"));
                
                ownerList.add(ow1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Dueño: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return ownerList;
    }
    
    
    public static void showOwnerList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<Owner> owners = getOwnerList();
            System.out.println("~~~~~~~~~~ LISTA DE DUEÑOS ~~~~~~~~~~");
            for(Owner ow1 : owners){
                System.out.println("Owner ID: " + ow1.getIdentification());
                System.out.println("Full Name: " + ow1.getName());
                System.out.println("Address: " + ow1.getAddress());
                System.out.println("Phone: " + ow1.getPhone());
                System.out.println("Email: " + ow1.getEmail());
                System.out.println("Emergency contac Name: " + ow1.getEmergencyName());
                System.out.println("Emergency contac Phone: " + ow1.getEmergencyContact());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los Dueños: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
    
    
    
    
    
    
    
}











