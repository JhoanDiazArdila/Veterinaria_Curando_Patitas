/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class Vaccination {
    private int vaccinationId;
    private Service serviceId;
    private String vaccinationType;
    private String observation;
    private int duration;
    
    
    public Vaccination() {
    }

    public Vaccination(int vaccinationId) {
        this.vaccinationId = vaccinationId;
    }

    public Vaccination(int vaccinationId, String observaciones) {
        this.vaccinationId = vaccinationId;
        this.observation = observaciones;
    }
    
    public Vaccination(Service serviceId, String tipoVacuna, String observaciones,int duration) {
        this.serviceId = serviceId;
        this.vaccinationType = tipoVacuna;
        this.observation = observaciones;
        this.duration=duration;
    }
    
    
    //Getter and Setter 

    public int getVaccinationId() {
        return vaccinationId;
    }

    public void setVaccinationId(int vaccinationId) {
        this.vaccinationId = vaccinationId;
    }

    public Service getService() {
        return serviceId;
    }
    
    public void setService(Service serviceId) {
        this.serviceId = serviceId;
    }

    public void setServiceId(Service serviceId) {
        this.serviceId = serviceId;
    }

    public String getVaccinationType() {
        return vaccinationType;
    }

    public void setVaccinationType(String vaccinationType) {
        this.vaccinationType = vaccinationType;
    }

    public String getObservaciones() {
        return observation;
    }

    public void setObservaciones(String observaciones) {
        this.observation = observaciones;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
    
    
    
    
    
}




