/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */


public class InvoiceService extends InvoiceDetail {
    private int invoiceServiceId;
    private Invoice invoice;
    private Service service;
    private AditionalCharges aditionalCharges;

    public InvoiceService() {
    }

    public InvoiceService(int invoiceServiceId, Invoice invoice, Service service, int quantity) {
        super(quantity);
        this.invoiceServiceId = invoiceServiceId;
        this.invoice = invoice;
        this.service = service;
    }

    public InvoiceService(Invoice invoice, Service service, String description, int quantity) {
        super(description, quantity);
        this.invoice = invoice;
        this.service = service;
    }

    public InvoiceService(Invoice invoice, Service service, AditionalCharges aditionalCharges, String description, int quantity) {
        super(description, quantity);
        this.invoice = invoice;
        this.service = service;
        this.aditionalCharges = aditionalCharges;
    }
    
    
    
    public InvoiceService(int invoiceServiceId, AditionalCharges aditionalCharges) {
        this.invoiceServiceId = invoiceServiceId;
        this.aditionalCharges = aditionalCharges;
    }

    public InvoiceService(Invoice invoice, Service service, AditionalCharges aditionalCharges, String description, int quantity, double totalPrice) {
        super(description, quantity, totalPrice);
        this.invoice = invoice;
        this.service = service;
        this.aditionalCharges = aditionalCharges;
    }
    
    

    
    
    

    public int getInvoiceServiceId() {
        return invoiceServiceId;
    }

    public void setInvoiceServiceId(int invoiceServiceId) {
        this.invoiceServiceId = invoiceServiceId;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public AditionalCharges getAditionalCharges() {
        return aditionalCharges;
    }

    public void setAditionalCharges(AditionalCharges aditionalCharges) {
        this.aditionalCharges = aditionalCharges;
    }

    

    @Override
    public double getPrice() {
        double total = 0;
        total += service.getStandarPrice() * super.getQuantity(); // Calcula el precio total de los servicios
        if (aditionalCharges != null) {
            total *= aditionalCharges.getMultiplierValue();
        }

        super.setTotalPrice(total);
        return total;
    }
}

