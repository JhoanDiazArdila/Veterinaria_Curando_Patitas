/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Clases.Vaccination;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class VaccinationController {
    
    //Create Vaccination 
    public static boolean createVaccination( Service serviceId, String tipoVacuna, String observaciones)throws SQLException{
        
        Vaccination v1 = new Vaccination(serviceId, tipoVacuna, observaciones, 0);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Vaccination (service_id,vaccination_type, observation, duration) VALUES (?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(serviceId.getServiceId(),v1.getVaccinationType(),v1.getObservaciones(),v1.getDuration());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar la Vacuna");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    
    //Update Vaccination
    public static boolean updateVaccination(int vaccinationId, String observaciones)throws SQLException {
        
        Vaccination v1 = new Vaccination(vaccinationId, observaciones);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Vaccination SET observation = ? WHERE service_id = ?";
        
        
        List<Object> parametros = Arrays.asList(v1.getObservaciones(),v1.getVaccinationId());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar la Vacuna");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    //Delete Vaccination
    public static boolean deleteVaccination(int vaccinationId) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Vaccination WHERE service_id = ?";
        
        List<Object> parametros = Arrays.asList(vaccinationId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El Proveedor fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el Proveedor.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    
    //Get Vaccination
    
    public static Vaccination getVaccination(int vaccinationId) throws SQLException {
        
        Vaccination v1 = new Vaccination();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Vaccination WHERE service_id = ?";
        List<Object> parametros = Arrays.asList(vaccinationId);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                v1.setVaccinationId(rs.getInt("service_id"));
                v1.setVaccinationType(rs.getString("vaccination_type"));
                v1.setObservaciones(rs.getString("observation"));
                v1.setDuration(rs.getInt("duration"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Proveedor: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return v1;
    }
    
    //Show Vaccination List
    
    public static List<Vaccination> getVaccinationList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<Vaccination> vaccinationList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Vaccination";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                Vaccination v1 = new Vaccination();
                v1.setVaccinationId(rs.getInt("service_id"));
                v1.setVaccinationType(rs.getString("vaccination_type"));
                v1.setObservaciones(rs.getString("observation"));
                v1.setDuration(rs.getInt("duration"));
                
                vaccinationList.add(v1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener la vacunacion: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return vaccinationList;
    }
    
    public static void showVaccinationList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<Vaccination> vaccinations = getVaccinationList();
            System.out.println("~~~~~~~ LISTA DE VACUNACIONES ~~~~~~~");
            for(Vaccination v1 : vaccinations){
                System.out.println("Vacunacion ID: " + v1.getVaccinationId());
                System.out.println("Tipo de vacunacion: " + v1.getVaccinationType());
                System.out.println("Observacion: " + v1.getObservaciones());
                System.out.println("Duracion: " + v1.getDuration());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener las Vacunas: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
}



