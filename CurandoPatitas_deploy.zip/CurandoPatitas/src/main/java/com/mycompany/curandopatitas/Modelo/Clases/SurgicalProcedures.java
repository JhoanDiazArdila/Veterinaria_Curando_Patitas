/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class SurgicalProcedures {
    private int surgicalProceduresId;
    private Service serviceId;
    private String preoperativeDetails;
    private String procedureDetails;
    private String postoperativeFollowUp;
    private String recoveryEstimatedTime;

    public SurgicalProcedures() {
    }

    public SurgicalProcedures(int surgicalProceduresId) {
        this.surgicalProceduresId = surgicalProceduresId;
    }

    public SurgicalProcedures(int surgicalProceduresId, String preoperativeDetails, String postoperativeFollowUp) {
        this.surgicalProceduresId = surgicalProceduresId;
        this.preoperativeDetails = preoperativeDetails;
        this.postoperativeFollowUp = postoperativeFollowUp;
    }

    public SurgicalProcedures(Service serviceId, String preoperativeDetails, String procedureDetails, String postoperativeFollowUp, String recoveryEstimatedTime) {
        this.serviceId = serviceId;
        this.preoperativeDetails = preoperativeDetails;
        this.procedureDetails = procedureDetails;
        this.postoperativeFollowUp = postoperativeFollowUp;
        this.recoveryEstimatedTime = recoveryEstimatedTime;
    }

    

    public int getSurgicalProceduresId() {
        return surgicalProceduresId;
    }

    public void setSurgicalProceduresId(int surgicalProceduresId) {
        this.surgicalProceduresId = surgicalProceduresId;
    }
    
    public void setService(Service serviceId) {
        this.serviceId = serviceId;
    }

    public void setServiceId(Service serviceId) {
        this.serviceId = serviceId;
    }

    public String getPreoperativeDetails() {
        return preoperativeDetails;
    }

    public void setPreoperativeDetails(String preoperativeDetails) {
        this.preoperativeDetails = preoperativeDetails;
    }

    public String getProcedureDetails() {
        return procedureDetails;
    }

    public void setProcedureDetails(String procedureDetails) {
        this.procedureDetails = procedureDetails;
    }

    public String getPostoperativeFollowUp() {
        return postoperativeFollowUp;
    }

    public void setPostoperativeFollowUp(String postoperativeFollowUp) {
        this.postoperativeFollowUp = postoperativeFollowUp;
    }

    public String getRecoveryEstimatedTime() {
        return recoveryEstimatedTime;
    }

    public void setRecoveryEstimatedTime(String recoveryEstimatedTime) {
        this.recoveryEstimatedTime = recoveryEstimatedTime;
    }
    
}




