


package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum Sex {
    MALE,
    FEMALE;
    
    public static Sex chooseSex(int chooseSex) {
        switch(chooseSex) {
            case 1: return Sex.FEMALE;
            case 2: return Sex.MALE;
            default: throw new IllegalArgumentException("Sexo no válido");
        }
    }
    
}
