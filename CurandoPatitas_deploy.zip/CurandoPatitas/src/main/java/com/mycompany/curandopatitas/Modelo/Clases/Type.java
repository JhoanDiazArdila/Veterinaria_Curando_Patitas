/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum Type {
   
    DOG,
    CAT,
    SNAKE,
    TURTLE,
    PARROT,
    TORTOLA;

    public static Type chooseType(int chooseSize) {
        switch(chooseSize) {
            case 1: return Type.DOG;
            case 2: return Type.CAT;
            case 3: return Type.SNAKE;
            case 4: return Type.TURTLE;
            case 5: return Type.PARROT;
            case 6: return Type.TORTOLA;
            default: throw new IllegalArgumentException("Animal no válido");
        }
    }
    
}

