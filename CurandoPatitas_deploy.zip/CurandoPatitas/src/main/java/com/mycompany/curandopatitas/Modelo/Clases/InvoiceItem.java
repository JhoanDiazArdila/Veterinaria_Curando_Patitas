/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */


public class InvoiceItem extends InvoiceDetail {
    
    private int invoiceItemId;
    private Invoice invoice;
    private Inventory item;
    
    public InvoiceItem() {
    }

    public InvoiceItem(int invoiceItemId) {
        this.invoiceItemId = invoiceItemId;
    }

    

    public InvoiceItem(int invoiceItemId,Invoice invoice, Inventory item, int quantity) {
        super(quantity);
        this.invoice = invoice;
        this.item = item;
    }

    public InvoiceItem(Invoice invoice, Inventory item, String description, int quantity) {
        super(description, quantity);
        this.invoice = invoice;
        this.item = item;
    }
    
    

    public InvoiceItem(Invoice invoice, Inventory item, String description, int quantity, double totalPrice) {
        super(description, quantity, totalPrice);
        this.invoice = invoice;
        this.item = item;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public Inventory getItem() {
        return item;
    }

    public void setItem(Inventory item) {
        this.item = item;
    }

    public int getInvoiceItemId() {
        return invoiceItemId;
    }

    public void setInvoiceItemId(int invoiceItemId) {
        this.invoiceItemId = invoiceItemId;
    }
    
    

    @Override
    public double getPrice() {
        double total = 0;
        total += item.getSellPrice() * quantity;
        return total;
    }

    
}



