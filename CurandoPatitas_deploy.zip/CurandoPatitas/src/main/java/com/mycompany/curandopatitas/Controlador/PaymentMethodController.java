/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */


import com.mycompany.curandopatitas.Modelo.Clases.PaymentMethod;
import com.mycompany.curandopatitas.Modelo.Clases.Vaccination;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class PaymentMethodController {
    
    
    
    //Create payment method 
    public static boolean createPaymentMethod(String name)throws SQLException{
        
        PaymentMethod pm1 = new PaymentMethod(name);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Payment_method (name) VALUES (?)";

        List<Object> parametros = Arrays.asList(pm1.getName());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el metodo de pago");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    //Delete payment method 
    public static boolean deletePaymentMethod(int methodId) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Payment_method WHERE method_id = ?";
        
        List<Object> parametros = Arrays.asList(methodId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El metodo de pago  fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el  metodo de pago.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    //Get payment method 
    
    public static PaymentMethod getPaymentMethod(int methodId) throws SQLException {
        
        PaymentMethod pm1 = new PaymentMethod();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Payment_method WHERE method_id = ?";
        List<Object> parametros = Arrays.asList(methodId);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                pm1.setMethodId(rs.getInt("method_id"));
                pm1.setName(rs.getString("name"));

            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el metodo de pago: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return pm1;
    }
    
    //Show payment method  List
    
    public static List<PaymentMethod> getPaymentMethodList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<PaymentMethod> PaymentMethodList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Payment_method";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                PaymentMethod pm1 = new PaymentMethod();
                pm1.setMethodId(rs.getInt("method_id"));
                pm1.setName(rs.getString("name"));
                
                PaymentMethodList.add(pm1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener el metodo de pago: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return PaymentMethodList;
    }
    
    public static void ShowPaymentMethodList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<PaymentMethod> paymentMethods = getPaymentMethodList();
            System.out.println("~~~~~~~ LISTA METODOS DE PAGO ~~~~~~~");
            for(PaymentMethod pm1 : paymentMethods){
                System.out.println("Metodo de pago ID: " + pm1.getMethodId());
                System.out.println("Nombre metodo de pago: " + pm1.getName());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los metodos de pago: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
}

