/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.curandopatitas.Vista;

import com.mycompany.curandopatitas.Controlador.AditionalChargesController;
import com.mycompany.curandopatitas.Controlador.CompanyInformationController;
import com.mycompany.curandopatitas.Controlador.CompanyNotificationController;
import com.mycompany.curandopatitas.Controlador.EmployeeController;
import com.mycompany.curandopatitas.Controlador.InventoryController;
import com.mycompany.curandopatitas.Controlador.OwnerController;
import com.mycompany.curandopatitas.Controlador.PaymentMethodController;
import com.mycompany.curandopatitas.Controlador.Pet;
import com.mycompany.curandopatitas.Controlador.ScheduleController;
import com.mycompany.curandopatitas.Controlador.ServiceController;
import com.mycompany.curandopatitas.Controlador.SuplierController;
import com.mycompany.curandopatitas.Controlador.SurgicalProceduresController;
import com.mycompany.curandopatitas.Controlador.VaccinationController;
import com.mycompany.curandopatitas.Modelo.Clases.Animal;
import com.mycompany.curandopatitas.Modelo.Clases.AnimalBuilder;
import com.mycompany.curandopatitas.Modelo.Clases.Behavior;
import com.mycompany.curandopatitas.Modelo.Clases.Bird;
import com.mycompany.curandopatitas.Modelo.Clases.Cat;
import com.mycompany.curandopatitas.Modelo.Clases.CompanyInformation;
import com.mycompany.curandopatitas.Modelo.Clases.CompanyNotification;
import com.mycompany.curandopatitas.Modelo.Clases.Day;
import com.mycompany.curandopatitas.Modelo.Clases.Dog;
import com.mycompany.curandopatitas.Modelo.Clases.Employee;
import com.mycompany.curandopatitas.Modelo.Clases.EmployeeStatus;
import com.mycompany.curandopatitas.Modelo.Clases.Inventory;
import com.mycompany.curandopatitas.Modelo.Clases.ItemType;
import com.mycompany.curandopatitas.Modelo.Clases.JobPosition;
import com.mycompany.curandopatitas.Modelo.Clases.Owner;
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Clases.ServiceType;
import com.mycompany.curandopatitas.Modelo.Clases.Sex;
import com.mycompany.curandopatitas.Modelo.Clases.Size;
import com.mycompany.curandopatitas.Modelo.Clases.Tortola;
import com.mycompany.curandopatitas.Modelo.Clases.Type;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author jhoan
 */
public class CurandoPatitas {

    public static void main(String[] args) throws SQLException {
//            
//        Owner owner = new Owner("Jose", "321", "123", "Manuel", "123", "algo@gmail.com", "siempreViva");
        
//        Behavior behavior = Behavior.PASSIVE;
//        Sex sex = Sex.MALE;
//        Size size = Size.MEDIUM;
//        LocalDate birthdate = LocalDate.of(2022, 12, 1);
//        
//        Cat bird = new AnimalBuilder<>(Cat.class)
//                .setOwnerId(owner)
//                .setName("Orion")
//                .setRace("Criollo")
//                .setBehavior(behavior)
//                .setAge(2)
//                .setBirthdate(birthdate)
//                .setSex(sex)
//                .setMicrochipNumber("1236")
//                .setPhotoPath("urlPhoto")
//                .setWeight(10.5)
//                .setSize(size)
//                .setAllergies("cacao")
//                .setMedicalConditions("perfect")
//                .build();
//        
//        System.out.println(bird);
//        
//        
        
//                                        Crear Owner
//        OwnerController.createOwner(
//        "Miguel", "123","456", "Camila",
//                "123", "caasdgmail.com", "aeasd23");
        
//        OwnerController.showOwnerList();

//             CREAR OWNER VACIO
//        Owner owner = new Owner();

//    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

////        // obtener dueño
//        Owner owner = OwnerController.getOwner("null");
//        System.out.println(owner);
//        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
//

//      DAtos solicitados CREACION PET

//        String nombre = "Jose";
//        String raza = "de Esas que nadan";
//        int edad = 2;
//        
//        // COMPORTAMIENTO
//        int escogerBehavior = 2;
//        Behavior behavior = Behavior.chooseBehavior(escogerBehavior);
//        
//        // Nacimiento
//        String birth = "2022-10-15";
//        LocalDate birthDate = LocalDate.parse(birth);
//        
//        // SEXO
//        int escogerSex = 2;
//        Sex sex = Sex.chooseSex(escogerSex);
//        
//        //Mas datos
//        Double peso = 5.0;
//        
//        // PESO
//        int escogerTamano = 1;
//        Size size = Size.chooseSize(escogerTamano);
//        
//        String type = "Turtle";
//        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
//        
//        
//        Pet.createPet(owner, nombre, behavior, raza,
//                edad, birthDate, sex, "1432",
//                "1342.photo", peso, size, "Perros",
//                "JajA", type);
//        
//        
//        
//        Pet.showAnimalList();
//        Pet.deletePet(1);
//        Pet.showAnimalList();
//        Pet.showAnimalListByOwner("123");
//        Pet.showAnimalListByOwner("258");
//        Pet.showAnimalListByOwner("null");
            

// COMPANY
//        String identification ="152";
//        String name = "Curando Patitas";
//        String phone = "321";
//        String email = "curando123";
//        String address = "avenida";
//
//        CompanyInformationController.createCompany(identification, name, phone, email, address);
//        CompanyInformationController.showCompanyList();
//        CompanyInformation company = CompanyInformationController.getCompany("152");
//        System.out.println(company);
//    
//    //NOTIFICATION
//
//        String subject = "Perro nos callo la TOMBA";
//        String description = "Mi perro ud no ha probado la marihuanita?";
//        CompanyNotificationController.createCompanyNotification(company, subject, description);
//        CompanyNotificationController.showNotificationList();
////


// CREAR ITEM

//        String name = "Cortisol";
////
////        // ItemType
//        int escogerType = 2;
//        ItemType itemType = ItemType.chooseItemType(escogerType);
//     //----   
//        String subType = "No se que poner";
//        String manufacturer = "MK";
//        String lotNumber = "1251"; 
//        double sellPrice = 50.0; 
//        double purchasePrice = 10.0;
//        
//        // Nacimiento
//        String Date = "2022-10-15";
//        LocalDate expirationDate = LocalDate.parse(Date);
//     //---- 
//        int quantity = 100;
//
//        InventoryController.createItem(
//                name, itemType, subType, manufacturer, lotNumber, 
//                sellPrice, purchasePrice, expirationDate, quantity);
//
////      Mostrar Item y demas metodos
//     
//        InventoryController.showInventoryList();
//     

     
   // CREAR SERVICIO
   
        //Service Type
//        int escogerType = 4;
//        ServiceType type = ServiceType.chooseServiceType(escogerType);
//        
//        String name = "Cirugia de ojos";
//        String description = "Se le quita un ojito";
//        Double standar_price = 100.0;
//   
//        ServiceController.createService(type, name, description, standar_price);
//   
//        ServiceController.showServiceList();
//        Inventory item = InventoryController.getItem(1);
//        System.out.println(item);
//        
//        ServiceController.addItemToService(1, 1, 100);
        //ServiceController.showItemsAddedToService(1);
   

//        Service s1 = ServiceController.getService(1);  // Obtener obejto Servicio
        
// SURGICAL PROCEDURES
//        SurgicalProceduresController.createSurgicalProcedures(
//                s1, "Limpiar y afeitar", "cortar y cercenar",
//                "Serealizo bien", "2 week");
//        
        
//        SurgicalProceduresController.upSurgicalProcedures(1, "sss", "sasa");
//        SurgicalProceduresController.deleteSurgicalProcedures(1);
//        SurgicalProceduresController.getSurgicalProcedures(1);
//        SurgicalProceduresController.showSurgicalProceduresList();


//CREAR SUPLLIER ETC
        //SuplierController.createSupplier("31351", "x", "y", "i", "wasd", "asdada");
        //SuplierController.showSupplierList();
        //SuplierController.deleteSupplier("31351");
        //SuplierController.showSupplierList();
        //SuplierController.getSupplier("31351");
        //SuplierController.updateSupplier("31351","ff", "dd", "ss", "ss");
        //SuplierController.showSupplierList();

    //CREAR VACCINATION ETC
    //Service s1 = ServiceController.getService(1);
    
        //VaccinationController.createVaccination(s1, "ff", "gg");
        //VaccinationController.updateVaccination(1, "si funciona");
        //VaccinationController.deleteVaccination(1);
        //VaccinationController.showVaccinationList();

   // PAYMENT METHOD    
   
//        PaymentMethodController.createPaymentMethod("Debito");
//        PaymentMethodController.deletePaymentMethod(1);
//        PaymentMethodController.getPaymentMethod(1);
//        PaymentMethodController.ShowPaymentMethodList();


    // ADDITIONAL CHARGES
//        AditionalChargesController.createAditionalCharges(Type.CAT, Size.SMALL, 20.00);
//        AditionalChargesController.updateAditionalCharges(1, 2.0);
//        AditionalChargesController.deleteAditionalCharge(1);
//        AditionalChargesController.getAditionalCharge(1);
//        AditionalChargesController.showAditionalChargesList();


// EMPLOYEE
//        EmployeeController.createEmployee(
//                JobPosition.ACCOUNTANT, 
//                "finger.url", 
//                EmployeeStatus.VACATIONS, 
//                "1235", 
//                "Felipe", 
//                "987", 
//                "Felipe@gmail.com", 
//                "aveida123");
        
//        EmployeeController.updateEmployee(
//                "1235", 
//                "calle21", 
//                "789", 
//                "felipe", 
//                20.00);
        
//        EmployeeController.deleteEmployee("1235");
        
//        Employee e1 = EmployeeController.getEmployee("1235");
        
//        EmployeeController.getEmployeeList();
//        EmployeeController.showEmployeeList();


// SCHEDULE

//        Employee e1 = EmployeeController.getEmployee("1235");
//        
//        ScheduleController.createSchedule(
//                e1, 
//                Day.MONDAY, 
//                LocalTime.of(8, 0), 
//                LocalTime.of(16, 0));
        
//        ScheduleController.updateSchedule(
//                e1, 
//                Day.FRIDAY, 
//                LocalTime.of(2, 0), 
//                LocalTime.of(12, 40));
//        
//        ScheduleController.getScheduleList("1235");
//        ScheduleController.showScheduleList("1235");
//        
//        ScheduleController.showScheduleList("1235");



        
    }   
}
