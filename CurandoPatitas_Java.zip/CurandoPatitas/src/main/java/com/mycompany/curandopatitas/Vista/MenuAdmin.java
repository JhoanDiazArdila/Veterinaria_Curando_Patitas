/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Vista;

import com.mycompany.curandopatitas.Controlador.AditionalChargesController;
import com.mycompany.curandopatitas.Controlador.AppoimentController;
import com.mycompany.curandopatitas.Controlador.EmployeeController;
import com.mycompany.curandopatitas.Controlador.InventoryController;
import com.mycompany.curandopatitas.Controlador.InvoiceController;
import com.mycompany.curandopatitas.Controlador.InvoiceItemController;
import com.mycompany.curandopatitas.Controlador.InvoiceServiceController;
import com.mycompany.curandopatitas.Controlador.OwnerController;
import com.mycompany.curandopatitas.Controlador.Pet;
import com.mycompany.curandopatitas.Controlador.ServiceController;
import com.mycompany.curandopatitas.Controlador.SuplierController;
import com.mycompany.curandopatitas.Controlador.SurgicalProceduresController;
import com.mycompany.curandopatitas.Controlador.VaccinationController;
import com.mycompany.curandopatitas.Modelo.Clases.AditionalCharges;
import com.mycompany.curandopatitas.Modelo.Clases.Animal;
import com.mycompany.curandopatitas.Modelo.Clases.Appoiment;
import com.mycompany.curandopatitas.Modelo.Clases.AppointmentStatus;
import com.mycompany.curandopatitas.Modelo.Clases.Behavior;
import com.mycompany.curandopatitas.Modelo.Clases.CompanyInformation;
import com.mycompany.curandopatitas.Modelo.Clases.Dog;
import com.mycompany.curandopatitas.Modelo.Clases.Employee;
import com.mycompany.curandopatitas.Modelo.Clases.EmployeeStatus;
import com.mycompany.curandopatitas.Modelo.Clases.Inventory;
import com.mycompany.curandopatitas.Modelo.Clases.Invoice;
import com.mycompany.curandopatitas.Modelo.Clases.ItemType;
import com.mycompany.curandopatitas.Modelo.Clases.JobPosition;
import com.mycompany.curandopatitas.Modelo.Clases.Owner;
import com.mycompany.curandopatitas.Modelo.Clases.Service;
import com.mycompany.curandopatitas.Modelo.Clases.ServiceType;
import com.mycompany.curandopatitas.Modelo.Clases.Sex;
import com.mycompany.curandopatitas.Modelo.Clases.Size;
import com.mycompany.curandopatitas.Modelo.Clases.Supplier;
import com.mycompany.curandopatitas.Modelo.Clases.SurgicalProcedures;
import com.mycompany.curandopatitas.Modelo.Clases.Type;
import com.mycompany.curandopatitas.Modelo.Clases.Vaccination;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author jhoan
 */
public class MenuAdmin {
    private static Scanner scanner = new Scanner(System.in);
    
    
    public static void mostrarMenu() { 
        System.out.println("~~~ Menu Administrador ~~~"); 
        int opcion = -1; 
        do {
            try {
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("1. Manejar Dueños");
                System.out.println("2. Manejar Mascotas");
                System.out.println("3. Manejar Empleados");
                System.out.println("4. Manejar Servicios");
                System.out.println("5. Manejar Citas");
                System.out.println("6. Manejar Eventos");
                System.out.println("7. Manejar Inventario");
                System.out.println("8. Manejar Proveedores");
                System.out.println("9. Manejar Facturas");
                System.out.println("0. Salir");
                System.out.print("Seleccione una opción: ");

                opcion = scanner.nextInt();
                scanner.nextLine(); 

                switch (opcion) {
                    case 1 -> tableOwners();
                    case 2 -> tablePets();
                    case 3 -> tableEmployee();
                    case 4 -> tableServices();
                    case 5 -> tableAppoiments();
                    case 6 -> tableInventory();
                    case 7 -> tableSuppliers();
                    case 8 -> tableSurgical();
                    case 9 -> tableVaccination();
                    case 10 -> tableInvoices();
                    case 11 -> tableAdditionalCharges();
                    case 12 -> tableInvoiceItem();
                    case 13 -> tableInvoiceService();
                    case 0 -> System.out.println("Saliendo del programa...");
                    default -> System.out.println("Opción no válida, intenta de nuevo.");
                }
            } catch (InputMismatchException e) {
                // Capturar errores por entrada de datos no numéricos
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) {
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            }
        } while (opcion != 0);
    }
    
    
    public static void tableOwners() throws SQLException {
        
        System.out.println("~~~ Manejo de Datos Dueños ~~~"); 
        int opcion = -1; 
        do {
            System.out.println("1. Crear Dueño"); 
            System.out.println("2. Actualizar Dueño"); 
            System.out.println("3. Eliminar Dueño"); 
            System.out.println("4. Obtener Dueño");
            System.out.println("5. Mostrar Lista de Dueños");
            System.out.println("0. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            try {
                opcion = scanner.nextInt(); 
                scanner.nextLine(); 
                switch (opcion) {
                    case 1 -> { 
                        System.out.print("Nombre Completo: "); 
                        String name = scanner.nextLine();
                        System.out.print("Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Email: "); 
                        String email = scanner.nextLine(); 
                        System.out.print("Dirección: "); 
                        String address = scanner.nextLine(); 
                        System.out.print("Nombre de Contacto de Emergencia: "); 
                        String emergencyName = scanner.nextLine(); 
                        System.out.print("Teléfono de Contacto de Emergencia: ");
                        String emergencyContact = scanner.nextLine(); 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine(); 
                        OwnerController.createOwner(emergencyName, emergencyContact, identification, name, phone, email, address); 
                    } 
                    case 2 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        System.out.print("Nueva Dirección: "); 
                        String address = scanner.nextLine(); 
                        System.out.print("Nuevo Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Nuevo Email: "); 
                        String email = scanner.nextLine(); 
                        OwnerController.updateOwner(identification, address, phone, email); 
                    } 
                    case 3 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        OwnerController.deleteOwner(identification); 
                    } 
                    case 4 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        Owner owner = OwnerController.getOwner(identification); 
                        System.out.println(owner); 
                    } 
                    case 5 -> OwnerController.showOwnerList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida.");
                }
            } catch (InputMismatchException e) {
                // Capturar errores por entrada de datos no numéricos
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) {
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            }
        } while (opcion != 0);
    }
    
    
    public static void tablePets() { 
        System.out.println("~~~ Manejo de Datos Mascotas ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Mascota");
            System.out.println("2. Actualizar Mascota"); 
            System.out.println("3. Eliminar Mascota"); 
            System.out.println("4. Obtener Mascota"); 
            System.out.println("5. Mostrar Lista de Mascotas"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try{ 
                opcion = scanner.nextInt();
                scanner.nextLine(); 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("Dueño ID: "); 
                        String ownerId = scanner.nextLine(); 
                        System.out.print("Nombre de la Mascota: "); 
                        String name = scanner.nextLine(); 
                        System.out.println("Comportamiento: 1. AGGRESSIVE, 2. PASSIVE"); 
                        int behaviorChoice = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Raza: "); 
                        String breed = scanner.nextLine(); 
                        System.out.print("Edad: "); 
                        int age = scanner.nextInt(); 
                        scanner.nextLine(); 
                        System.out.print("Fecha de nacimiento (AAAA-MM-DD): "); 
                        String birthdateStr = scanner.nextLine(); 
                        LocalDate birthdate = LocalDate.parse(birthdateStr); 
                        System.out.println("Sexo: 1. FEMALE, 2. MALE"); 
                        int sexChoice = scanner.nextInt(); 
                        scanner.nextLine();
                        System.out.print("Número de microchip: ");
                        String microchipNumber = scanner.nextLine();
                        System.out.print("Ruta de la foto: "); 
                        String photoPath = scanner.nextLine();
                        System.out.print("Peso: "); 
                        double weight = scanner.nextDouble(); 
                        scanner.nextLine(); 
                        System.out.println("Tamaño: 1. SMALL, 2. MEDIUM, 3. BIG"); 
                        int sizeChoice = scanner.nextInt(); 
                        scanner.nextLine(); 
                        System.out.print("Alergias: "); 
                        String allergies = scanner.nextLine(); 
                        System.out.print("Condiciones médicas: "); 
                        String medicalConditions = scanner.nextLine(); 
                        System.out.print("Tipo de animal: "); 
                        String type = scanner.nextLine(); 
                        
                        Owner owner = new Owner(ownerId); 
                        
                        Behavior behaviorEnum = Behavior.chooseBehavior(behaviorChoice);
                        Sex sexEnum = Sex.chooseSex(sexChoice);
                        Size sizeEnum = Size.chooseSize(sizeChoice);
                        
                        Pet.createPet(owner, name, behaviorEnum, breed, age, 
                                birthdate, sexEnum, microchipNumber, photoPath, 
                                weight, sizeEnum, allergies, medicalConditions, type);
                    }
                    case 2 -> { 
                        System.out.print("ID de la Mascota: "); 
                        int petId = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("Dueño ID: "); 
                        String ownerId = scanner.nextLine(); 
                        System.out.print("Nombre de la Mascota: "); 
                        String name = scanner.nextLine(); 
                        System.out.print("Peso: "); 
                        double weight = scanner.nextDouble(); 
                        scanner.nextLine(); 
                        System.out.print("Ruta de la foto: "); 
                        String photoPath = scanner.nextLine(); 
                        Owner owner = new Owner(ownerId); 
                        Pet.updatePet(petId, owner, name, weight, photoPath);
                    }
                    case 3 -> { 
                        System.out.print("ID de la Mascota: "); 
                        int petId = scanner.nextInt();
                        scanner.nextLine(); 
                        Pet.deletePet(petId);
                    }
                    case 4 -> { 
                        System.out.print("ID de la Mascota: "); 
                        int petId = scanner.nextInt();
                        scanner.nextLine(); 
                        Animal pet = Pet.getPet(petId); System.out.println(pet);
                    }
                    case 5 -> Pet.showAnimalList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                }
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            }    
        } while (opcion != 0);
    }
    
    
    public static void tableEmployee() { 
        System.out.println("~~~ Manejo de Datos Empleados ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Empleado");
            System.out.println("2. Actualizar Empleado"); 
            System.out.println("3. Eliminar Empleado"); 
            System.out.println("4. Obtener Empleado"); 
            System.out.println("5. Mostrar Lista de Empleados");
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine(); 
                switch (opcion) {
                    case 1 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        System.out.print("Nombre Completo: "); 
                        String name = scanner.nextLine(); 
                        System.out.print("Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Email: "); 
                        String email = scanner.nextLine(); 
                        System.out.print("Dirección: "); 
                        String address = scanner.nextLine(); 
                        System.out.print("URL de Huella Digital: "); 
                        String digitalFingerPrintUrl = scanner.nextLine(); 
                        
                        System.out.println("Puesto de Trabajo: 1. VETERINARIAN, 2. RECEPTIONIST, 3. VETERINARY_HEAD, "
                                + "4. ACCOUNTANT, 5. LAWYER, 6. GENERAL_ADMINISTRATOR, 7. CLEANING"); 
                        int jobPositionChoice = scanner.nextInt(); 
                        scanner.nextLine(); 
                        
                        System.out.println("Estado del Empleado: 1. ACTIVE, 2. INACTIVE, 3. VACATIONS"); 
                        int employeeStatusChoice = scanner.nextInt();
                        scanner.nextLine();
                        
                        JobPosition jobPosition = JobPosition.chooseJobPosition(jobPositionChoice); 
                        EmployeeStatus employeeStatus = EmployeeStatus.chooseEmployeeStatus(employeeStatusChoice);
                        
                        EmployeeController.createEmployee(
                                jobPosition, digitalFingerPrintUrl, employeeStatus, 
                                identification, name, phone, email, address);
                    }
                    case 2 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        System.out.print("Nueva Dirección: "); 
                        String address = scanner.nextLine(); 
                        System.out.print("Nuevo Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Nuevo Email: "); 
                        String email = scanner.nextLine(); 
                        System.out.print("Nuevo Salario: "); 
                        double salary = scanner.nextDouble(); 
                        scanner.nextLine();
                        
                        EmployeeController.updateEmployee(identification, address, phone, email, salary);
                    }
                    case 3 -> { 
                        System.out.print("Identificación: ");
                        String identification = scanner.nextLine(); 
                        EmployeeController.deleteEmployee(identification);                    
                    }
                    case 4 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        Employee employee = EmployeeController.getEmployee(identification); 
                        System.out.println(employee);
                    }
                    case 5 -> EmployeeController.showEmployeeList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida.");    
                }
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            }
        } while (opcion != 0); 
    }
        
    
    public static void tableServices() { 
        System.out.println("~~~ Manejo de Datos Servicios ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Servicio");
            System.out.println("2. Actualizar Servicio"); 
            System.out.println("3. Eliminar Servicio"); 
            System.out.println("4. Obtener Servicio"); 
            System.out.println("5. Mostrar Lista de Servicios"); 
            System.out.println("6. Añadir Artículo al Servicio"); 
            System.out.println("7. Eliminar Artículo del Servicio"); 
            System.out.println("8. Mostrar Artículos Añadidos al Servicio"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: ");
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine(); 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("Tipo de Servicio: 1. VACCINATION, "
                                + "2. ADDITIONAL_SERVICE, 3. MEDICAL_CONSULTATIONS, "
                                + "4. SURGICAL_PROCEDURES, 5.ADOPTIONS"); 
                        int serviceTypeChoose = scanner.nextInt(); 
                        scanner.nextLine(); 
                        
                        System.out.print("Nombre del Servicio: "); 
                        String name = scanner.nextLine(); 
                        System.out.print("Descripción del Servicio: "); 
                        String description = scanner.nextLine(); 
                        System.out.print("Precio Estándar: "); 
                        double standarPrice = scanner.nextDouble(); 
                        scanner.nextLine(); 
                        
                        ServiceType serviceType = ServiceType.chooseServiceType(serviceTypeChoose);
                        ServiceController.createService(serviceType, name, description, standarPrice); 
                    }
                    case 2 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine();  
                        System.out.print("Nueva Descripción: "); 
                        String description = scanner.nextLine(); 
                        System.out.print("Nuevo Precio Estándar: "); 
                        double standarPrice = scanner.nextDouble(); 
                        scanner.nextLine(); 
                        
                        ServiceController.updateService(description, standarPrice, serviceId); 
                    }
                    case 3 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); 
                        ServiceController.deleteService(serviceId);
                    } 
                    case 4 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); 
                        Service service = ServiceController.getService(serviceId); 
                        System.out.println(service); 
                    }
                    case 5 -> ServiceController.showServiceList(); 
                    case 6 -> { 
                        System.out.print("ID del Artículo: "); 
                        int itemId = scanner.nextInt();
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt(); 
                        System.out.print("Cantidad: "); 
                        int quantity = scanner.nextInt(); 
                        scanner.nextLine(); 
                        ServiceController.addItemToService(itemId, serviceId, quantity); 
                    }
                    case 7 -> { 
                        System.out.print("ID del Artículo: "); 
                        int itemId = scanner.nextInt();
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt(); 
                        scanner.nextLine(); 
                        ServiceController.deleteItemFromService(itemId, serviceId); 
                    }
                    case 8 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); 
                        ServiceController.showItemsAddedToService(serviceId); 
                    }
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                } 
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    }
                    
                    
    public static void tableAppoiments() { 
        System.out.println("~~~ Manejo de Datos Citas ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Cita");
            System.out.println("2. Actualizar Cita"); 
            System.out.println("3. Eliminar Cita"); 
            System.out.println("4. Obtener Cita"); 
            System.out.println("5. Mostrar Lista de Citas"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine();
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("ID del Empleado: "); 
                        String employId = scanner.nextLine(); 
                        System.out.print("ID de la Mascota: "); 
                        int petId = scanner.nextInt(); 
                        scanner.nextLine(); 
                        
                        System.out.print("Fecha y Hora de Entrada (AAAA-MM-DDTHH:MM): "); 
                        String entryDateTimeStr = scanner.nextLine(); 
                        LocalDateTime entryDateTime = LocalDateTime.parse(entryDateTimeStr); 
                        
                        System.out.print("Fecha y Hora de Salida (AAAA-MM-DDTHH:MM): "); 
                        String exitDateTimeStr = scanner.nextLine(); 
                        LocalDateTime exitDateTime = LocalDateTime.parse(exitDateTimeStr); 
                        
                        System.out.print("Motivo de la Visita: "); 
                        String visitReason = scanner.nextLine(); 
                        System.out.print("Diagnóstico: "); 
                        String diagnosis = scanner.nextLine(); 
                        System.out.print("Recomendaciones: "); 
                        String recomendations = scanner.nextLine(); 
                        System.out.print("Medicamentos Recetados: "); 
                        String prescriptionMedicines = scanner.nextLine(); 
                        
                        System.out.println("Estado de la Cita: 1. SCHEDULED, 2. IN_PROGRESS, 3. COMPLETED, 4. CANCELLED"); 
                        int statusChoice = scanner.nextInt(); 
                        scanner.nextLine();
                        
                        AppointmentStatus status = AppointmentStatus.chooseAppoimentStatus(statusChoice); 
                        Service service = new Service(serviceId); 
                        Employee employee = new Employee(employId); 
                        Animal pet = new Dog(petId);
                        
                        AppoimentController.createAppoiment(
                                service, employee, pet, entryDateTime, exitDateTime, 
                                visitReason, diagnosis, recomendations, prescriptionMedicines, 
                                status);
                    }
                    case 2 -> { 
                        System.out.print("ID de la Cita: "); 
                        int appoimentId = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("ID del Empleado: "); 
                        String employId = scanner.nextLine(); 
                        System.out.print("Fecha y Hora de Entrada (AAAA-MM-DDTHH:MM): "); 
                        String entryDateTimeStr = scanner.nextLine(); 
                        LocalDateTime entryDateTime = LocalDateTime.parse(entryDateTimeStr); 
                        System.out.print("Fecha y Hora de Salida (AAAA-MM-DDTHH:MM): "); 
                        String exitDateTimeStr = scanner.nextLine(); 
                        LocalDateTime exitDateTime = LocalDateTime.parse(exitDateTimeStr); 
                        
                        System.out.println("Estado de la Cita: 1. SCHEDULED, 2. IN_PROGRESS, 3. COMPLETED, 4. CANCELLED"); 
                        int statusChoice = scanner.nextInt(); 
                        scanner.nextLine();
                        
                        AppointmentStatus status = AppointmentStatus.chooseAppoimentStatus(statusChoice); 
                        Employee employee = new Employee(employId);
                        
                        AppoimentController.updateAppoiment(
                                appoimentId, employee, entryDateTime, exitDateTime, status);
                    }
                    case 3 -> {
                        System.out.print("ID de la Cita: "); 
                        int appoimentId = scanner.nextInt();
                        scanner.nextLine();
                        AppoimentController.deleteAppoiment(appoimentId);
                    }
                    case 4 -> { 
                        System.out.print("ID de la Cita: "); 
                        int appoimentId = scanner.nextInt();
                        scanner.nextLine(); 
                        Appoiment appoiment = AppoimentController.getAppoiment(appoimentId); 
                        System.out.println(appoiment); 
                    }
                    case 5 -> AppoimentController.showInventoryList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                }
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    }
    
    
    public static void tableInventory() { 
        System.out.println("~~~ Manejo de Inventario ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Artículo");
            System.out.println("2. Actualizar Artículo"); 
            System.out.println("3. Eliminar Artículo"); 
            System.out.println("4. Obtener Artículo"); 
            System.out.println("5. Mostrar Lista de Artículos"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try {
                opcion = scanner.nextInt(); 
                scanner.nextLine(); 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("Nombre del Artículo: "); 
                        String name = scanner.nextLine();
                        
                        System.out.println("Tipo de Artículo: 1. MEDICATION, 2. VACCINE, 3. MEDICAL_SUPPLY"); 
                        int itemTypeChoice = scanner.nextInt(); 
                        scanner.nextLine(); 
                        
                        System.out.print("Subtipo del Artículo: "); 
                        String subType = scanner.nextLine(); 
                        System.out.print("Fabricante: "); 
                        String manufacturer = scanner.nextLine(); 
                        System.out.print("Número de Lote: "); 
                        String lotNumber = scanner.nextLine(); 
                        System.out.print("Precio de Venta: "); 
                        double sellPrice = scanner.nextDouble(); 
                        System.out.print("Precio de Compra: "); 
                        double purchasePrice = scanner.nextDouble(); 
                        
                        System.out.print("Fecha de Expiración (AAAA-MM-DD): "); 
                        String expirationDateStr = scanner.next(); 
                        LocalDate expirationDate = LocalDate.parse(expirationDateStr); 
                        
                        System.out.print("Cantidad: "); 
                        int quantity = scanner.nextInt(); 
                        scanner.nextLine(); 
                        
                        ItemType itemType = ItemType.chooseItemType(itemTypeChoice); 
                        
                        InventoryController.createItem(
                                name, itemType, subType, manufacturer, lotNumber, 
                                sellPrice, purchasePrice, expirationDate, quantity); 
                    }
                    case 2 -> { 
                        System.out.print("ID del Artículo: "); 
                        int itemId = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("Nuevo Precio de Venta: "); 
                        double sellPrice = scanner.nextDouble(); 
                        System.out.print("Nuevo Precio de Compra: "); 
                        double purchasePrice = scanner.nextDouble(); 
                        System.out.print("Nueva Cantidad: "); 
                        int quantity = scanner.nextInt(); 
                        scanner.nextLine(); 
                        InventoryController.updateItem(itemId, sellPrice, purchasePrice, quantity); 
                    }
                    case 3 -> { 
                        System.out.print("ID del Artículo: "); 
                        int itemId = scanner.nextInt();
                        scanner.nextLine(); 
                        InventoryController.deleteItem(itemId); 
                    }
                    case 4 -> { 
                        System.out.print("ID del Artículo: "); 
                        int itemId = scanner.nextInt();
                        scanner.nextLine(); 
                        Inventory item = InventoryController.getItem(itemId); 
                        System.out.println(item); 
                    }
                    case 5 -> InventoryController.showInventoryList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal...");
                    default -> System.out.println("Opción no válida.");
                }
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    }
    
    
    public static void tableSuppliers() { 
        System.out.println("~~~ Manejo de Proveedores ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Proveedor");
            System.out.println("2. Actualizar Proveedor"); 
            System.out.println("3. Eliminar Proveedor"); 
            System.out.println("4. Obtener Proveedor"); 
            System.out.println("5. Mostrar Lista de Proveedores"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try {
                opcion = scanner.nextInt(); 
                scanner.nextLine(); 
                switch (opcion) { 
                    case 1 -> {
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine(); 
                        System.out.print("Nombre de la Compañía: "); 
                        String name = scanner.nextLine(); 
                        System.out.print("Nombre del Contacto: "); 
                        String contactName = scanner.nextLine(); 
                        System.out.print("Email: "); 
                        String email = scanner.nextLine(); 
                        System.out.print("Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Dirección: "); 
                        String address = scanner.nextLine(); 
                        SuplierController.createSupplier(
                                identification, name, contactName, 
                                email, phone, address);
                    }
                    case 2 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        System.out.print("Nuevo Nombre del Contacto: "); 
                        String contactName = scanner.nextLine(); 
                        System.out.print("Nuevo Email: "); 
                        String email = scanner.nextLine(); 
                        System.out.print("Nuevo Teléfono: "); 
                        String phone = scanner.nextLine(); 
                        System.out.print("Nueva Dirección: "); 
                        String address = scanner.nextLine(); 
                        SuplierController.updateSupplier(identification, contactName, email, phone, address); 
                    }
                    case 3 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        SuplierController.deleteSupplier(identification); 
                    } 
                    case 4 -> { 
                        System.out.print("Identificación: "); 
                        String identification = scanner.nextLine();
                        Supplier supplier = SuplierController.getSupplier(identification); 
                        System.out.println(supplier); 
                    }
                    case 5 -> SuplierController.showSupplierList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida.");
                    } 
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); // Limpiar el buffer del scanner 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            } 
        } while (opcion != 0);
    }
    
    
    public static void tableSurgical() { 
        System.out.println("~~~ Manejo de Procedimientos Quirúrgicos ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Procedimiento Quirúrgico");
            System.out.println("2. Actualizar Procedimiento Quirúrgico"); 
            System.out.println("3. Eliminar Procedimiento Quirúrgico"); 
            System.out.println("4. Obtener Procedimiento Quirúrgico"); 
            System.out.println("5. Mostrar Lista de Procedimientos Quirúrgicos"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try {
                opcion = scanner.nextInt(); 
                scanner.nextLine(); 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("Detalles Preoperativos: "); 
                        String preoperativeDetails = scanner.nextLine(); 
                        System.out.print("Detalles del Procedimiento: "); 
                        String procedureDetails = scanner.nextLine(); 
                        System.out.print("Seguimiento Post Operativo: "); 
                        String postoperativeFollowUp = scanner.nextLine(); 
                        System.out.print("Tiempo Estimado de Recuperación: "); 
                        String recoveryEstimatedTime = scanner.nextLine(); 
                        Service service = new Service(serviceId); 
                        SurgicalProceduresController.createSurgicalProcedures(
                                service, preoperativeDetails, procedureDetails, 
                                postoperativeFollowUp, recoveryEstimatedTime); 
                    }
                    case 2 -> { 
                        System.out.print("ID del Procedimiento Quirúrgico: "); 
                        int surgicalProceduresId = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        System.out.print("Nuevos Detalles Preoperativos: "); 
                        String preoperativeDetails = scanner.nextLine(); 
                        System.out.print("Nuevo Seguimiento Post Operativo: "); 
                        String postoperativeFollowUp = scanner.nextLine(); 
                        SurgicalProceduresController.upSurgicalProcedures(
                                surgicalProceduresId, preoperativeDetails, 
                                postoperativeFollowUp); 
                    }
                    case 3 -> { 
                        System.out.print("ID del Procedimiento Quirúrgico: "); 
                        int surgicalProceduresId = scanner.nextInt();
                        scanner.nextLine(); 
                        SurgicalProceduresController.deleteSurgicalProcedures(surgicalProceduresId); 
                    }
                    case 4 -> { 
                        System.out.print("ID del Procedimiento Quirúrgico: ");
                        int surgicalProceduresId = scanner.nextInt();
                        scanner.nextLine(); 
                        SurgicalProcedures surgicalProcedure = SurgicalProceduresController.getSurgicalProcedures(surgicalProceduresId); 
                        System.out.println(surgicalProcedure); 
                    } 
                    case 5 -> SurgicalProceduresController.showSurgicalProceduresList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                }
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); // Limpiar el buffer del scanner 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    }
    
    
    public static void tableVaccination() { 
        System.out.println("~~~ Manejo de Vacunaciones ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Vacunación");
            System.out.println("2. Actualizar Vacunación"); 
            System.out.println("3. Eliminar Vacunación"); 
            System.out.println("4. Obtener Vacunación"); 
            System.out.println("5. Mostrar Lista de Vacunaciones");
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine(); 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("Tipo de Vacuna: "); 
                        String tipoVacuna = scanner.nextLine(); 
                        System.out.print("Observaciones: "); 
                        String observaciones = scanner.nextLine(); 
                        Service service = new Service(serviceId); 
                        VaccinationController.createVaccination(service, tipoVacuna, observaciones); 
                    } case 2 -> { 
                        System.out.print("ID de la Vacunación: "); 
                        int vaccinationId = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("Nuevas Observaciones: "); 
                        String observaciones = scanner.nextLine(); 
                        VaccinationController.updateVaccination(vaccinationId, observaciones); 
                    } case 3 -> { 
                        System.out.print("ID de la Vacunación: "); 
                        int vaccinationId = scanner.nextInt();
                        scanner.nextLine(); 
                        VaccinationController.deleteVaccination(vaccinationId); 
                    }
                    case 4 -> { 
                        System.out.print("ID de la Vacunación: ");
                        int vaccinationId = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        Vaccination vaccination = VaccinationController.getVaccination(vaccinationId); 
                        System.out.println(vaccination); 
                    } 
                    case 5 -> 
                        VaccinationController.showVaccinationList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal...");
                    default -> System.out.println("Opción no válida."); 
                } 
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); // Limpiar el buffer del scanner 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    }
    
    
    public static void tableAdditionalCharges() { 
        System.out.println("~~~ Manejo de Cargos Adicionales ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Cargo Adicional");
            System.out.println("2. Actualizar Cargo Adicional"); 
            System.out.println("3. Eliminar Cargo Adicional"); 
            System.out.println("4. Obtener Cargo Adicional"); 
            System.out.println("5. Mostrar Lista de Cargos Adicionales"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.println("Tipo de Animal: 1. DOG, 2. CAT, 3.SNAKE ,4.TURTLE ,5.PARROT ,6.TORTOLA"); 
                        int typeChoice = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        
                        System.out.println("Tamaño: 1. SMALL, 2. MEDIUM, 3. BIG"); 
                        int sizeChoice = scanner.nextInt(); 
                        scanner.nextLine(); // Consumir el salto de línea 
                        
                        System.out.print("Valor Multiplicador: "); 
                        double multiplierValue = scanner.nextDouble(); 
                        scanner.nextLine(); // Consumir el salto de línea 
                        
                        Type type = Type.chooseType(typeChoice); 
                        Size size = Size.chooseSize(sizeChoice); 
                        AditionalChargesController.createAditionalCharges(type, size, multiplierValue); 
                    } 
                    case 2 -> { 
                        System.out.print("ID del Cargo Adicional: "); 
                        int chargeId = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        System.out.print("Nuevo Valor Multiplicador: "); 
                        double multiplierValue = scanner.nextDouble(); 
                        scanner.nextLine(); // Consumir el salto de línea 
                        AditionalChargesController.updateAditionalCharges(chargeId, multiplierValue); 
                    } 
                    case 3 -> { 
                        System.out.print("ID del Cargo Adicional: "); 
                        int chargeId = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        AditionalChargesController.deleteAditionalCharge(chargeId); 
                    } 
                    case 4 -> { 
                        System.out.print("ID del Cargo Adicional: "); 
                        int chargeId = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        AditionalCharges aditionalCharge = AditionalChargesController.getAditionalCharge(chargeId);
                        System.out.println(aditionalCharge); 
                    } 
                    case 5 -> AditionalChargesController.showAditionalChargesList(); 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                }
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); // Limpiar el buffer del scanner 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    }
    
    
    public static void tableInvoices() { 
        System.out.println("~~~ Manejo de Facturas ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Factura");
            System.out.println("2. Obtener Factura"); 
            System.out.println("3. Mostrar Lista de Facturas"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea 
                switch (opcion) { 
                    case 1 -> { System.out.print("CUFE: "); 
                    String CUFE = scanner.nextLine();
                    System.out.print("Identificación del Dueño: "); 
                    String ownerId = scanner.nextLine(); 
                    System.out.print("NIT de la Compañía: "); 
                    String companyNit = scanner.nextLine(); 
                    System.out.print("Monto del Impuesto: "); 
                    double taxAmount = scanner.nextDouble(); 
                    scanner.nextLine(); // Consumir el salto de línea 
                    System.out.print("Sello Digital: "); 
                    String digitalStamp = scanner.nextLine(); 
                    System.out.print("Ruta del Código QR: "); 
                    String qr_code_path = scanner.nextLine(); 
                    Owner owner = new Owner(ownerId); 
                    CompanyInformation companyInformation = new CompanyInformation(companyNit); 
                    InvoiceController.createInvoice(
                            CUFE, owner, companyInformation, taxAmount, digitalStamp, 
                            qr_code_path); 
                    } 
                    case 2 -> { 
                        System.out.print("CUFE: "); 
                        String CUFE = scanner.nextLine();
                        Invoice invoice = InvoiceController.getInvoice(CUFE); 
                        System.out.println(invoice); 
                    } 
                    case 3 -> { 
                        System.out.print("CUFE: "); String CUFE = scanner.nextLine();
                        InvoiceController.showInvoiceList(CUFE); 
                    } 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                } 
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); // Limpiar el buffer del scanner 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    } 

    
    public static void tableInvoiceItem() { 
        System.out.println("~~~ Manejo de Artículos de Factura ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Artículo de Factura");
            System.out.println("2. Mostrar Artículos de Factura"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("ID del Artículo: "); 
                        int itemId = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        System.out.print("CUFE: "); 
                        String CUFE = scanner.nextLine(); 
                        System.out.print("Descripción: "); 
                        String description = scanner.nextLine(); 
                        System.out.print("Cantidad: "); 
                        int quantity = scanner.nextInt(); 
                        scanner.nextLine(); // Consumir el salto de línea 
                        Inventory item = InventoryController.getItem(itemId); 
                        Invoice invoice = InvoiceController.getInvoice(CUFE); 
                        InvoiceItemController.createInvoiceItem(
                                invoice, item, description, quantity); 
                    } 
                    case 2 -> { 
                        System.out.print("CUFE: "); 
                        String CUFE = scanner.nextLine();
                        InvoiceController.showInvoiceList(CUFE); 
                    } 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                } 
            } catch (InputMismatchException e) { 
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); // Limpiar el buffer del scanner 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage());
            } 
        
        } while (opcion != 0);
    }
    
    
    public static void tableInvoiceService() { 
        System.out.println("~~~ Manejo de Servicios de Factura ~~~");
        int opcion = -1; 
        do { 
            System.out.println("1. Crear Servicio de Factura");
            System.out.println("2. Mostrar Servicios de Factura"); 
            System.out.println("0. Volver al Menú Principal"); 
            System.out.print("Seleccione una opción: "); 
            try { 
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea 
                switch (opcion) { 
                    case 1 -> { 
                        System.out.print("ID del Servicio: "); 
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        System.out.print("CUFE: "); 
                        String CUFE = scanner.nextLine(); 
                        System.out.print("ID del Cargo Adicional: "); 
                        int chargeId = scanner.nextInt(); 
                        scanner.nextLine(); // Consumir el salto de línea 
                        System.out.print("Descripción: ");
                        String description = scanner.nextLine();
                        System.out.print("Cantidad: "); 
                        int quantity = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea 
                        Service service = ServiceController.getService(serviceId);
                        Invoice invoice = InvoiceController.getInvoice(CUFE);
                        AditionalCharges aditionalCharges = AditionalChargesController.getAditionalCharge(chargeId);
                        InvoiceServiceController.createInvoiceService(
                                invoice, service, aditionalCharges, description, quantity); 
                    } 
                    case 2 -> { 
                        System.out.print("CUFE: "); 
                        String CUFE = scanner.nextLine();
                        InvoiceController.showInvoiceList(CUFE); 
                    } 
                    case 0 -> System.out.println("Volviendo al Menú Principal..."); 
                    default -> System.out.println("Opción no válida."); 
                } 
            } catch (InputMismatchException e) {
                System.out.println("Error: Debes ingresar un número válido.");
                scanner.nextLine(); // Limpiar el buffer del scanner 
            } catch (Exception e) { 
                System.out.println("Ocurrió un error inesperado: " + e.getMessage()); 
            } 
        } while (opcion != 0); 
    }
    
    
}                   
