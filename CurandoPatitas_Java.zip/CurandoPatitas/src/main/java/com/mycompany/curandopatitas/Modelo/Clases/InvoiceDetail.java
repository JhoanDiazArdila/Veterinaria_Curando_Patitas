/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */


public abstract class InvoiceDetail {
    protected String description;
    protected int quantity;
    protected double totalPrice;

    public InvoiceDetail() {
    }

    public InvoiceDetail(int quantity) {
        this.quantity = quantity;
    }

    public InvoiceDetail(String description, int quantity) {
        this.description = description;
        this.quantity = quantity;
        this.totalPrice = 0;
    }
    
    

    public InvoiceDetail(String description, int quantity, double totalPrice) {
        this.description = description;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
    }

    public String getDescription() {
        return description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    // Método abstracto para calcular el precio total
    public abstract double getPrice();
    
    
}

