/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class ConcreteAnimalFactory implements AnimalFactory{

    @Override
    public Mammal createMammal() {
        return new Dog();
    }

    @Override
    public Reptile createReptile() {
        return new Turtle();
    }

    @Override
    public Bird createBird() {
        return new Tortola();
    }
    
}
