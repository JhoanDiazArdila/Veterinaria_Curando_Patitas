



package com.mycompany.curandopatitas.Modelo.Clases;

import java.util.ArrayList;

/**
 *
 * @author jhoan
 */
public class Service {
    private int serviceId;
    private ServiceType serviceType;
    private String name;
    private String description;
    private double standarPrice;
    private ArrayList<Inventory> inventories;

    // Constructor, getters and setters
    
    public Service(int par, ServiceType VACCINATION, String aja, String ojo, double par1){}
    
    public Service(int serviceId){
        this.serviceId = serviceId;
    }
    
    public Service (int serviceId, String description, double standarPrice){
        this.serviceId = serviceId;
        this.description = description;
        this.standarPrice = standarPrice;
    }
    
    public Service(ServiceType serviceType, String name, String description, double standarPrice) {
        this.serviceType = serviceType;
        this.name = name;
        this.description = description;
        this.standarPrice = standarPrice;
        this.inventories = new ArrayList<>();
    }

    
    

    // getters and setters
    public String getDescription() {
        return description;
    }

    public double getStandarPrice() {
        return standarPrice;
    }
    
    public int getServiceId() {
        return serviceId;
    }

    public String getServiceName() {
        return name;
    }
    
    public ServiceType getServiceType() {    
        return serviceType;
    }

    public String getName() {
        return name;
    }
    
    public void setServiceId(int serviceId) {
        this.serviceId = serviceId;
    }

    public void setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setStandarPrice(double standarPrice) {
        this.standarPrice = standarPrice;
    }

    
    // Methods to manage the ArrayList
    public void addInventory(Inventory item) {
        this.inventories.add(item);
    }
    
    public void removeInventory(Inventory item) {
        this.inventories.remove(item);
    }
    
    public ArrayList<Inventory> getInventories() {
        return inventories;
    }

    public Inventory getInventory(int index) {
        return this.inventories.get(index);
    }

 
    public void setInventories(ArrayList<Inventory> item) {
        this.inventories = item;
    }

    
    
    @Override
    public String toString() {
        return "~~~~~~~~~~~~ Service ~~~~~~~~~~~~" + 
                "\nService Id: " + serviceId + 
                "\nService Type: " + serviceType + 
                "\nName: " + name + 
                "\nDescription: " + description + 
                "\nStandar Price: " + standarPrice + 
                "\nInventories: " + inventories + 
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }
    
    
    
    
       
}
