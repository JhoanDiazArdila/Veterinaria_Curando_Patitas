


package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class Employee extends User{
    
    
    private JobPosition jobPosition;
    private String digitalFingerPrintUrl;
    private EmployeeStatus employeeStatus;
    private double salary;
    
    
    // CONSTRUCTOR
    
    public Employee(){}
    
    
    public Employee(String identification){
        this.identification = identification;
    }
    
    public Employee(String identification, String address, String phone, String email,double salary){
        this.identification = identification;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.salary = salary;
    }

    public Employee(String identification, EmployeeStatus employeeStatus) {
        this.identification = identification;
        this.employeeStatus = employeeStatus;
    }
    

    public Employee(JobPosition jobPosition, String digitalFingerPrintUrl, 
            EmployeeStatus employeeStatus, String identification, String name, 
            String phone, String email, String address) {
        
        super(identification, name, phone, email, address);
        this.jobPosition = jobPosition;
        this.digitalFingerPrintUrl = digitalFingerPrintUrl;
        this.employeeStatus = employeeStatus;
    }

    
    
    // GETTERS AND SETTERS

    public JobPosition getJobPosition() {
        return jobPosition;
    }

    public void setJobPosition(JobPosition jobPosition) {
        this.jobPosition = jobPosition;
    }

    public String getDigitalFingerPrintUrl() {
        return digitalFingerPrintUrl;
    }

    public void setDigitalFingerPrintUrl(String digitalFingerPrintUrl) {
        this.digitalFingerPrintUrl = digitalFingerPrintUrl;
    }

    public EmployeeStatus getEmployeeStatus() {
        return employeeStatus;
    }

    public void setEmployeeStatus(EmployeeStatus employeeStatus) {
        this.employeeStatus = employeeStatus;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    
    

    @Override
    public String toString() {
        return "\nJob Position: " + jobPosition + 
                "\nDigital Finger Print Url: " + digitalFingerPrintUrl + 
                "\nEmployee Status: " + employeeStatus + 
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }
    
    
}
