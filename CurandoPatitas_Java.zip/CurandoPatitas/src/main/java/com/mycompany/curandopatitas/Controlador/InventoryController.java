

package com.mycompany.curandopatitas.Controlador;

import com.mycompany.curandopatitas.Modelo.Clases.Inventory;
import com.mycompany.curandopatitas.Modelo.Clases.ItemType;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class InventoryController {
    
    //Crate Item
    
    public static boolean createItem(String name, ItemType itemType, String subType, 
            String manufacturer,String lotNumber, double sellPrice, double purchasePrice, 
            LocalDate expirationDate, int quantity){
    
        
        Inventory in1 = new Inventory(name, itemType, subType, manufacturer,
                lotNumber, sellPrice, purchasePrice, expirationDate, quantity);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = 
                "INSERT INTO Inventory "
                + "(name, item_type, sub_type, manufacturer, lot_number, "
                + "sell_price, purchase_price, expiration_date, quantity)"
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
        List<Object> parametros = Arrays.asList(
                in1.getName(),
                in1.getItemType().name(),
                in1.getSubType(),
                in1.getManufacturer(),
                in1.getLotNumber(),
                in1.getSellPrice(),
                in1.getPurchasePrice(),
                in1.getExpirationDate(),
                in1.getQuantity());
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el Articulo");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    //Update Item
    
    public static boolean updateItem(int itemId, double sellPrice,
            double purchasePrice, int quantity)throws SQLException{
        
        Inventory in1 = new Inventory(itemId, sellPrice, purchasePrice, quantity);
        
        CRUD.setConnection(Conexion.getConexion());
        String actualizacion = 
                "UPDATE Inventory SET sell_price = ?, purchase_price = ?, quantity = ? WHERE item_id = ?";
        
        List<Object> parametros = Arrays.asList(
                in1.getSellPrice(),in1.getPurchasePrice(),
                in1.getQuantity(), in1.getItemId());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar el Articulo");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    
    public static boolean deleteItem(int itemId) throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        String delete = "DELETE FROM Inventory WHERE item_id = ?";
        
        List<Object> parameters = Arrays.asList(itemId);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(delete, parameters)){
                    System.out.println("El Articulo fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el Articulo.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    
    }
    
    
    public static Inventory getItem(int itemId) throws SQLException {
        
        Inventory in1 = new Inventory();
        CRUD.setConnection(Conexion.getConexion());
        
        String obtener = "SELECT * FROM Inventory WHERE item_id = ?";
        List<Object> parametros = Arrays.asList(itemId);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                in1.setItemId(rs.getInt("item_id"));
                in1.setName(rs.getString("name"));
                in1.setItemType(ItemType.valueOf(rs.getString("item_type")));
                in1.setSubType(rs.getString("sub_type"));
                in1.setManufacturer(rs.getString("manufacturer"));
                in1.setLotNumber(rs.getString("lot_number"));
                in1.setSellPrice(rs.getDouble("sell_price"));
                in1.setPurchasePrice(rs.getDouble("purchase_price"));
                in1.setExpirationDate(rs.getDate("expiration_date").toLocalDate());
                in1.setQuantity(rs.getInt("quantity"));
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Item " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return in1;
    }
    
    
    public static List<Inventory> getInventoryList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<Inventory> inventoryList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Inventory";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                Inventory in1 = new Inventory();
                in1.setItemId(rs.getInt("item_id"));
                in1.setName(rs.getString("name"));
                in1.setItemType(ItemType.valueOf(rs.getString("item_type")));
                in1.setSubType(rs.getString("sub_type"));
                in1.setManufacturer(rs.getString("manufacturer"));
                in1.setLotNumber(rs.getString("lot_number"));
                in1.setSellPrice(rs.getDouble("sell_price"));
                in1.setPurchasePrice(rs.getDouble("purchase_price"));
                in1.setExpirationDate(rs.getDate("expiration_date").toLocalDate());
                in1.setQuantity(rs.getInt("quantity"));
                
                inventoryList.add(in1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener la lista de Inventario: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return inventoryList;
    }
    
    
    public static void showInventoryList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<Inventory> items = getInventoryList();
            System.out.println("~~~~~~~~~~~~~ LISTA DE ARTICULOS ~~~~~~~~~~~~~");
            for(Inventory in1 : items){
                System.out.println("item ID: " + in1.getItemId());
                System.out.println("item Name: " + in1.getName());
                System.out.println("Item Type: " + in1.getItemType());
                System.out.println("Sub Type: " + in1.getSubType());
                System.out.println("Manufacturer: " + in1.getManufacturer());
                System.out.println("Lot Number: " + in1.getLotNumber());
                System.out.println("Sell Price: " + in1.getSellPrice());
                System.out.println("Purchase Price: " + in1.getPurchasePrice());
                System.out.println("Expiration Date: " + in1.getExpirationDate());
                System.out.println("Quantity: " + in1.getQuantity());
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los items: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
    
    
    
}