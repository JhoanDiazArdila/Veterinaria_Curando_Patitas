/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public enum Size {
    BIG,
    MEDIUM,
    SMALL;

    public static Size chooseSize(int chooseSize) {
        switch(chooseSize) {
            case 1: return Size.SMALL;
            case 2: return Size.MEDIUM;
            case 3: return Size.BIG;
            default: throw new IllegalArgumentException("Tamaño no válido");
        }
    }
    
}
