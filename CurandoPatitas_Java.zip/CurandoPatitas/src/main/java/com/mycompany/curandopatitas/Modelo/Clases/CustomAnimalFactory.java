/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */

// Se selecciona el Type para poder crear esa clase predeterminada
public class CustomAnimalFactory implements AnimalFactory{
    
    private String type;

    public CustomAnimalFactory(String type) {
        this.type = type;
    }


    @Override
    public Mammal createMammal() {
        if ("Cat".equalsIgnoreCase(type)) {
            return new Cat();
        }
        return new Dog();
    }

    @Override
    public Reptile createReptile() {
        if ("Snake".equalsIgnoreCase(type)) {
            return new Snake();
        }
        return new Turtle();
    }

    @Override
    public Bird createBird() {
        if ("Parrot".equalsIgnoreCase(type)) {
            return new Parrot();
        }
        return new Tortola();
    }
    
}
