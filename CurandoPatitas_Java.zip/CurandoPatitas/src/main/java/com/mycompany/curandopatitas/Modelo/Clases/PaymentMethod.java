/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class PaymentMethod {
    private int methodId;
    private String name;

    
    public PaymentMethod() {}

    
    public PaymentMethod(int methodId) {
        this.methodId = methodId;
    }

    public PaymentMethod(String name) {
        this.name = name;
    }

    // GETTERS AND SETTERS
    
    
    public int getMethodId() {
        return methodId;
    }

    public void setMethodId(int methodId) {
        this.methodId = methodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
}
