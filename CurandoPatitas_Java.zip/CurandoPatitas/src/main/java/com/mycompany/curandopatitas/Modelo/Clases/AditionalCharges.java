/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class AditionalCharges {
    private int chargeId;
    private Type type;
    private Size size;
    private double multiplierValue;

    
    //CONSTRUCTOR
    public AditionalCharges() {}

    
    public AditionalCharges(int chargeId) {
        this.chargeId = chargeId;
    }

    public AditionalCharges(int chargeId, double multiplierValue) {
        this.chargeId = chargeId;
        this.multiplierValue = multiplierValue;
    }

    public AditionalCharges(Type type, Size size, double multiplierValue) {
        this.type = type;
        this.size = size;
        this.multiplierValue = multiplierValue;
    }

    
    
    // GETTERS && SETTERS
    
    public int getChargeId() {
        return chargeId;
    }

    public void setChargeId(int chargeId) {
        this.chargeId = chargeId;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }

    public double getMultiplierValue() {
        return multiplierValue;
    }

    public void setMultiplierValue(double multiplierValue) {
        this.multiplierValue = multiplierValue;
    }

}

