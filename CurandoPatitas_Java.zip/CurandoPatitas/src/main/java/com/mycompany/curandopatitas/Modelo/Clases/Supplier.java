/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

/**
 *
 * @author jhoan
 */
public class Supplier extends User{
    
    private String contacName;
    
    // CONSTRUCTOR
    
    public Supplier(){}

    public Supplier( String identification){
        this.identification = identification;
    }
    
    public Supplier( String identification ,String contacName,  String email,String phone, String address) {
        this.identification = identification;
        this.contacName = contacName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        
    }
    
    public Supplier( String identification, String name,String contacName,  String email,String phone, String address) {
        super(identification, name, phone, email, address);
        this.contacName = contacName;
    }

    // GETTERS AND SETTERS
    
    public String getContacName() {    
        return contacName;
    }
    public void setContacName(String contacName) {
        this.contacName = contacName;
    }

    @Override
    public String toString() {
        return "~~~~~~~~~ PROVEEDORES ~~~~~~~~~" + 
                "\nIdentificacion: " + identification + 
                "\nNombre de la compañia: " + name + 
                "\nNombre de contato: " + contacName +
                "\nTelfono: " + phone + 
                "\nEmail: " + email + 
                "\nDireccion: " + address + 
                 
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }
    
    
    
    
}

