/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Controlador;

/**
 *
 * @author jhoan
 */
import com.mycompany.curandopatitas.Modelo.Clases.Supplier;
import com.mycompany.curandopatitas.Modelo.Persistencia.CRUD;
import com.mycompany.curandopatitas.Modelo.Persistencia.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SuplierController {
    
    //Create Suplier
    public static boolean createSupplier( String identification, String name,String contacName, String email,String phone, String addresss)throws SQLException{
        
        Supplier sp1 = new Supplier(identification, name, contacName, email, phone, addresss);
        
        CRUD.setConnection(Conexion.getConexion());
        
        String insercion = "INSERT INTO Suppliers (supplier_id,company_name, contact_name, email, phone, address) VALUES (?, ?, ?, ?, ?, ?)";

        List<Object> parametros = Arrays.asList(sp1.getIdentification(), sp1.getName(),sp1.getContacName(),
                sp1.getEmail(),sp1.getPhone(),sp1.getAddress());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        CRUD.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar el Proveedor");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD();
            throw ex;
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion(); 
        }
        return false;
    }
    
    
    //update Supplier
    public static boolean updateSupplier(String identification, String contacName,  String email,String phone, String address)throws SQLException {
        
        Supplier sp1 = new Supplier(identification, contacName, email, phone, address);
        CRUD.setConnection(Conexion.getConexion());
        
        String actualizacion = "UPDATE Suppliers SET contact_name = ?, email = ?, phone = ?, address = ? WHERE supplier_id = ?";
        System.out.println(sp1.getContacName());
        
        List<Object> parametros = Arrays.asList(sp1.getContacName(), sp1.getEmail(), sp1.getPhone(), sp1.getAddress(), sp1.getIdentification());
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                
                if(CRUD.actualizarBD1(actualizacion, parametros)){
                    System.out.println("Actualizacion exitosa!!");
                    CRUD.commitBD();
                    return true;
                } else {
                    System.out.println("Error al actualizar el Proveedor");
                    CRUD.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();  
        }
        return false;
    }
    
    //Delete Supplier
    public static boolean deleteSupplier(String identification) throws SQLException {
        
        CRUD.setConnection(Conexion.getConexion());
        
        String borrar = "DELETE FROM Suppliers WHERE supplier_id = ?";
        
        List<Object> parametros = Arrays.asList(identification);
        
        try{
            if(CRUD.setAutoCommitBD(false)){
                if(CRUD.borrarBD1(borrar, parametros)){
                    System.out.println("El Proveedor fue eliminado exitosamente.");
                    CRUD.commitBD(); 
                    return true;
                }else{
                    System.out.println("Error al eliminar el Proveedor.");
                    CRUD.rollbackBD(); 
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            CRUD.rollbackBD(); 
            throw ex; 
        } finally {
            
            CRUD.setAutoCommitBD(true);
            CRUD.cerrarConexion();
        }
        return false;
    }
    
    //Get Supplier
    
    public static Supplier getSupplier(String identification) throws SQLException {
        
        Supplier sp1 = new Supplier();
        CRUD.setConnection(Conexion.getConexion());
        String obtener = "SELECT * FROM Suppliers WHERE supplier_id = ?";
        List<Object> parametros = Arrays.asList(identification);
        
        try {
            ResultSet rs = CRUD.consultarBD1(obtener, parametros);
            
            if(rs.next()){
                sp1.setIdentification(rs.getString("supplier_id"));
                sp1.setName(rs.getString("company_name"));
                sp1.setContacName(rs.getString("contact_name"));
                sp1.setEmail(rs.getString("email"));
                sp1.setPhone(rs.getString("phone"));
                sp1.setAddress(rs.getString("address"));
                
            }
            rs.close();  
            
        }catch (SQLException ex) {
            System.out.println("Error al obtener el Proveedor: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }

        return sp1;
    }
    
    public static List<Supplier> getSupplierList() throws SQLException{
        
        CRUD.setConnection(Conexion.getConexion());
        List<Supplier> supplierList = new ArrayList<>();
        
        try{
            String obtener = "SELECT * FROM Suppliers";
            ResultSet rs = CRUD.consultarBD1(obtener, new ArrayList<>());
            while(rs.next()){
                Supplier sp1 = new Supplier();
                sp1.setIdentification(rs.getString("supplier_id"));
                sp1.setName(rs.getString("company_name"));
                sp1.setContacName(rs.getString("contact_name"));
                sp1.setEmail(rs.getString("email"));
                sp1.setPhone(rs.getString("phone"));
                sp1.setAddress(rs.getString("address"));
                
                supplierList.add(sp1);  
            }
        }catch (SQLException ex) {
            System.out.println("Error al obtener el proveedor: " + ex.getMessage());
            throw ex; 
        } finally {
            
            CRUD.cerrarConexion();
        }
        return supplierList;
    }
    
    
    public static void showSupplierList(){
        try{
            CRUD.setConnection(Conexion.getConexion());
            List<Supplier> suppliers = getSupplierList();
            System.out.println("~~~~~~~ LISTA DE PROVEEDORES ~~~~~~~");
            for(Supplier sp1 : suppliers){
                System.out.println("Proveedor ID: " + sp1.getIdentification());
                System.out.println("Nombre Compañia: " + sp1.getName());
                System.out.println("Nombtre Contacto: " + sp1.getContacName());
                System.out.println("Email: " + sp1.getEmail());
                System.out.println("Telefono: " + sp1.getPhone());
                System.out.println("Direccion: " + sp1.getAddress());
                System.out.println("");
            }
            CRUD.cerrarConexion();
        } catch (SQLException e) {
            System.out.println("Error al obtener los proveedores: " + e.getMessage());
            CRUD.cerrarConexion();
        }
        
    }
    
}




