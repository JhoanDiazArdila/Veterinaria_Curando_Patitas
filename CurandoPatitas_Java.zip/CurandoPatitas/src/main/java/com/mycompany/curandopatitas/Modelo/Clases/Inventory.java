/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curandopatitas.Modelo.Clases;

import java.time.LocalDate;


/**
 *
 * @author camid
 */
public class Inventory {
    private int itemId;
    private String name;
    private ItemType itemType;
    private String subType;
    private String manufacturer;
    private String lotNumber;
    private double sellPrice;
    private double purchasePrice;
    private LocalDate expirationDate;
    private int quantity;

    // Constructor, getters y setters
    
    public Inventory(){}
    
    public Inventory(int itemId){
        this.itemId = itemId;
    }    
    
    public Inventory(int itemId, double sellPrice, double purchasePrice, int quantity) {
        this.itemId = itemId;
        this.sellPrice = sellPrice;
        this.purchasePrice = purchasePrice;
        this.quantity = quantity;
    }
    
    public Inventory( String name, ItemType itemType, String subType, String manufacturer,
                     String lotNumber, double sellPrice, double purchasePrice, 
                     LocalDate expirationDate, int quantity) {
        
        this.name = name;
        this.itemType = itemType;
        this.subType = subType;
        this.manufacturer = manufacturer;
        this.lotNumber = lotNumber;
        this.sellPrice = sellPrice;
        this.purchasePrice = purchasePrice;
        this.expirationDate = expirationDate;
        this.quantity = quantity;
    }

    
    
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ItemType getItemType() {
        return itemType;
    }

    public void setItemType(ItemType itemType) {
        this.itemType = itemType;
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getLotNumber() {
        return lotNumber;
    }

    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    public double getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(double sellPrice) {
        this.sellPrice = sellPrice;
    }

    public double getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(double purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    
    @Override
    public String toString() {
        return "~~~~~~~~~~~~ Articulo ~~~~~~~~~~~~" + 
                "\nItem Id: " + itemId + 
                "\nName: " + name + 
                "\nItem Type: " + itemType + 
                "\nSub Type: " + subType + 
                "\nManufacturer: " + manufacturer + 
                "\nLot Number: " + lotNumber + 
                "\nSell Price: " + sellPrice + 
                "\nPurchase Price: " + purchasePrice + 
                "\nExpiration Date: " + expirationDate + 
                "\nQuantity: " + quantity + 
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }
    
    


    
    

    
}